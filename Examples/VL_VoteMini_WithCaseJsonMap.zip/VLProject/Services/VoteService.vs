// VL_VERSION:4.1
<ServiceDomain-VoteService>

# Backend Tree
<ServiceDomainRoot-Root>
-<VirtualTable-PollQuestions "questionTable"> sourceTable:PollQuestions
--<Field-code> type:STRING
--<Field-title> type:STRING
--<Field-questionType> type:STRING
--<Field-required> type:BOOL
--<Field-options> type:JSON
--<Field-sortOrder> type:INT
-<VirtualTable-VoteResponses "responseTable"> sourceTable:VoteResponses
--<Field-singleChoice> type:STRING
--<Field-multiChoices> type:JSON

# Services
SERVICE GetVoteBoard();RETURN {success:BOOL,questions:[{}],summary:{},results:{},message:STRING}
-<VirtualTable-PollQuestions "questionTable">.select(null,[["sortOrder","asc"],["_update","desc"]],[0,20]) -> _questionResult
-<VirtualTable-VoteResponses "responseTable">.select(null,[["_update","desc"]],[0,500]) -> _responseResult
-buildBoard(_questionResult.dataArray, _responseResult.dataArray) -> _boardResult
-RETURN {success:true,questions:_boardResult.questions,summary:_boardResult.summary,results:_boardResult.results,message:""}

SERVICE SubmitVote(singleChoice(STRING),multiChoices([STRING]));RETURN {success:BOOL,questions:[{}],summary:{},results:{},message:STRING}
-_selectedSingle(STRING) = singleChoice.trim()
-normalizeChoiceList(multiChoices) -> _multiResult
-IF _selectedSingle == ""
--RETURN {success:false,questions:[],summary:{},results:{},message:"请选择一个单选答案"}
-IF _multiResult.choices.length == 0
--RETURN {success:false,questions:[],summary:{},results:{},message:"请选择至少一个多选因素"}
-<VirtualTable-PollQuestions "questionTable">.select(null,[["sortOrder","asc"],["_update","desc"]],[0,20]) -> _questionResult
-IF _questionResult.dataArray.length == 0
--RETURN {success:false,questions:[],summary:{},results:{},message:"当前没有可提交的投票题目"}
-buildQuestionMeta(_questionResult.dataArray) -> _metaResult
-IF !_metaResult.singleCodes.includes(_selectedSingle)
--RETURN {success:false,questions:[],summary:{},results:{},message:"单选答案不在当前题目选项中"}
-_validMulti([STRING]) = []
-FOR (_item0, _index0) IN _multiResult.choices
--IF _metaResult.multiCodes.includes(_item0)
---_validMulti.push(_item0)
-IF _validMulti.length == 0
--RETURN {success:false,questions:[],summary:{},results:{},message:"多选答案不在当前题目选项中"}
-<VirtualTable-VoteResponses "responseTable">.insert({singleChoice:_selectedSingle,multiChoices:_validMulti}) -> _insertResult
-IF !_insertResult.success
--RETURN {success:false,questions:[],summary:{},results:{},message:_insertResult.message}
-<VirtualTable-VoteResponses "responseTable">.select(null,[["_update","desc"]],[0,500]) -> _responseResult
-buildBoard(_questionResult.dataArray, _responseResult.dataArray) -> _boardResult
-RETURN {success:true,questions:_boardResult.questions,summary:_boardResult.summary,results:_boardResult.results,message:"投票已提交，结果已更新"}

# Backend Event Handlers

# Transactions

# Backend Internal Methods
METHOD normalizeChoiceList(rawChoices([STRING]));RETURN {choices:[STRING]}
-_choices([STRING]) = []
-FOR (_item0, _index0) IN rawChoices
--_choice(STRING) = (_item0 && _item0.trim().length > 0 ? _item0.trim() : "")
--IF _choice != "" && !_choices.includes(_choice)
---_choices.push(_choice)
-RETURN {choices:_choices}

METHOD buildQuestionMeta(questionRows([{}]));RETURN {singleCodes:[STRING],multiCodes:[STRING]}
-_singleCodes([STRING]) = []
-_multiCodes([STRING]) = []
-FOR (_item0, _index0) IN questionRows
--IF _item0.questionType == "single" && _item0.options && _item0.options.length > 0
---FOR (_item1, _index1) IN _item0.options
----IF _item1.code && !_singleCodes.includes(_item1.code)
-----_singleCodes.push(_item1.code)
--ELSE IF _item0.questionType == "multi" && _item0.options && _item0.options.length > 0
---FOR (_item1, _index1) IN _item0.options
----IF _item1.code && !_multiCodes.includes(_item1.code)
-----_multiCodes.push(_item1.code)
-RETURN {singleCodes:_singleCodes,multiCodes:_multiCodes}

METHOD buildOptionStats(optionRows([{}]), countMap({}), totalCount(INT));RETURN {options:[{}],topLabel:STRING}
-_options([{}]) = []
-_topLabel(STRING) = "-"
-_topCount(INT) = 0
-FOR (_item0, _index0) IN optionRows
--_count(INT) = (countMap[_item0.code] ? countMap[_item0.code] : 0)
--_percent(INT) = (totalCount > 0 ? Math.round((_count / totalCount) * 100) : 0)
--_isTop(BOOL) = (_count > _topCount)
--IF _isTop
---_topCount = _count
---_topLabel = _item0.label
--_options.push({code:_item0.code,label:_item0.label,count:_count,percent:_percent,isTop:_isTop})
-RETURN {options:_options,topLabel:_topLabel}

METHOD buildBoard(questionRows([{}]),responseRows([{}]));RETURN {questions:[{}],summary:{},results:{}}
-_questions([{}]) = []
-_singleOptions([{}]) = []
-_multiOptions([{}]) = []
-FOR (_item0, _index0) IN questionRows
--_optionRows([{}]) = []
--IF _item0.options && _item0.options.length > 0
---FOR (_item1, _index1) IN _item0.options
----_optionRows.push({code:_item1.code,label:_item1.label})
--_questions.push({code:_item0.code,title:_item0.title,questionType:_item0.questionType,required:_item0.required,options:_optionRows,sortOrder:_item0.sortOrder})
--IF _item0.questionType == "single"
---_singleOptions = _optionRows
--ELSE IF _item0.questionType == "multi"
---_multiOptions = _optionRows
-_singleCounts({}) = {}
-_multiCounts({}) = {}
-_multiSelections(INT) = 0
-FOR (_item2, _index2) IN responseRows
--_singleCode(STRING) = (_item2.singleChoice && _item2.singleChoice.trim().length > 0 ? _item2.singleChoice.trim() : "")
--IF _singleCode != ""
---IF !_singleCounts[_singleCode]
----_singleCounts[_singleCode] = 0
---_singleCounts[_singleCode] = _singleCounts[_singleCode] + 1
--IF _item2.multiChoices && _item2.multiChoices.length > 0
---FOR (_item3, _index3) IN _item2.multiChoices
----_multiCode(STRING) = (_item3 && _item3.trim().length > 0 ? _item3.trim() : "")
----IF _multiCode != ""
-----IF !_multiCounts[_multiCode]
------_multiCounts[_multiCode] = 0
-----_multiCounts[_multiCode] = _multiCounts[_multiCode] + 1
-----_multiSelections = _multiSelections + 1
-buildOptionStats(_singleOptions, _singleCounts, responseRows.length) -> _singleResult
-buildOptionStats(_multiOptions, _multiCounts, _multiSelections) -> _multiResult
-RETURN {questions:_questions,summary:{totalVotes:responseRows.length,topSingleLabel:_singleResult.topLabel,topMultiLabel:_multiResult.topLabel,singleVoteCount:responseRows.length,multiVoteCount:_multiSelections},results:{singleOptions:_singleResult.options,multiOptions:_multiResult.options}}

# Backend Pipeline Funcs
</ServiceDomain-VoteService>
