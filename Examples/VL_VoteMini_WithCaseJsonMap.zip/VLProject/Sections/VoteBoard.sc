// VL_VERSION:4.1
// Preview: width:100% min-height:1080px
<Section-VoteBoard "root"> gap:"24px"

# Frontend Public Props

# Frontend Public Events

# Frontend Public Methods
METHOD LoadBoard();RETURN {success:BOOL}
-loadBoard() -> _result
-RETURN {success:_result.success}

# Frontend Global Vars
$questionList([{code:STRING,title:STRING,questionType:STRING,required:BOOL,options:[{code:STRING,label:STRING}],sortOrder:INT}]) = []
$summary({totalVotes:INT,topSingleLabel:STRING,topMultiLabel:STRING,singleVoteCount:INT,multiVoteCount:INT}) = {totalVotes:0,topSingleLabel:"-",topMultiLabel:"-",singleVoteCount:0,multiVoteCount:0}
$resultBoard({singleOptions:[{code:STRING,label:STRING,count:INT,percent:INT,isTop:BOOL}],multiOptions:[{code:STRING,label:STRING,count:INT,percent:INT,isTop:BOOL}]}) = {singleOptions:[],multiOptions:[]}
$selectedSingle(STRING) = ""
$selectedMulti([STRING]) = []
$submitState(STRING) = "idle"
$statusMessage(STRING) = ""
$showValidation(BOOL) = false
$isLoading(BOOL) = false

# Frontend Derived Vars
$hasQuestions(BOOL) = ($questionList.length > 0)
$completedCount(INT) = (($selectedSingle.trim().length > 0 ? 1 : 0) + ($selectedMulti.length > 0 ? 1 : 0))
$progressPercent(INT) = ($completedCount * 50)
$progressLabel(STRING) = (("" + $progressPercent) + "%")
$singleQuestionTitle(STRING) = ($questionList.length > 0 ? $questionList[0].title : "单选题")
$multiQuestionTitle(STRING) = ($questionList.length > 1 ? $questionList[1].title : "多选题")
$singleRequiredLabel(STRING) = ($questionList.length > 0 && $questionList[0].required ? "必答" : "")
$multiRequiredLabel(STRING) = ($questionList.length > 1 && $questionList[1].required ? "必答" : "")
$canSubmit(BOOL) = ($submitState == "idle" && $selectedSingle.trim().length > 0 && $selectedMulti.length > 0 && !$isLoading)
$submitButtonLabel(STRING) = ($submitState == "submitting" ? "提交中..." : "提交投票")
$boardHint(STRING) = ($submitState == "submitted" ? "投票已提交，下面是最新结果。" : "完成两道必答题后即可提交。")
$submissionStatusLabel(STRING) = ($submitState == "submitted" ? "已提交" : ($submitState == "submitting" ? "提交中" : "待作答"))

# Frontend Tree
<ServiceDomain-VoteService "voteService">
-<Service-GetVoteBoard> params:() returns:(success(BOOL),questions([{}]),summary({}),results({}),message(STRING))
-<Service-SubmitVote> params:(singleChoice(STRING),multiChoices([STRING])) returns:(success(BOOL),questions([{}]),summary({}),results({}),message(STRING))

<Col-VoteShell "voteShell"> gap:"24px" max-width:"1320px" margin:"0 auto"
-<Col-HeroPanel "heroPanel"> style:"neutral|soft|elevated|passive" padding:"28px" gap:"18px" sk.bgImage:"linear-gradient(135deg, rgba(219,234,254,0.88), rgba(255,255,255,1))"
--<Row-HeroTop "heroTop"> width:"100%" justify-content:"space-between" align-items:"flex-start" gap:"18px" flex-wrap:"wrap"
---<Col-HeroCopy "heroCopy"> gap:"10px" flex:"1"
----<Text-Overline "overline"> value:"VOTE MINI" style:"caption"
----<Text-Title "title"> value:"中文投票小应用" style:"contrast" font-size:"34px" font-weight:"700" line-height:"1.15"
----<Text-Desc "desc"> value:"支持单选、多选、提交状态、结果统计、进度条与条件渲染，适合直接验证 VL 3.7 的投票场景。" style:"body" line-height:"1.7" sk.fg:"#475569" max-width:"860px"
---<Col-StatusPanel "statusPanel"> style:"neutral|soft|solid|passive" padding:"16px" gap:"8px" min-width:"300px"
----<Text-StatusLabel "statusLabel"> value:"当前状态" style:"caption"
----<Text-StatusValue "statusValue"> value:$submissionStatusLabel style:"contrast" font-size:"22px" font-weight:"700"
----<Text-StatusMessage "statusMessage"> value:($statusMessage.trim().length > 0 ? $statusMessage : $boardHint) style:"body" sk.fg:"#64748B"
-<Row-StatRow "statRow"> gap:"16px" flex-wrap:"wrap"
--<Component-VoteStatCard "totalVotesCard"> label:"累计投票" value:("" + $summary.totalVotes) helper:"当前数据库中的响应总数" accentColor:"#2563EB" flex:"1 1 220px" min-width:"220px"
--<Component-VoteStatCard "singleTopCard"> label:"单选热门" value:$summary.topSingleLabel helper:"eventType 题目的最高票选项" accentColor:"#F59E0B" flex:"1 1 220px" min-width:"220px"
--<Component-VoteStatCard "multiTopCard"> label:"多选热门" value:$summary.topMultiLabel helper:"decisionFactors 题目的最高频因素" accentColor:"#10B981" flex:"1 1 220px" min-width:"220px"
--<Component-VoteStatCard "multiCountCard"> label:"多选总勾选" value:("" + $summary.multiVoteCount) helper:"所有多选选项累计出现次数" accentColor:"#EF4444" flex:"1 1 220px" min-width:"220px"

-<If-SubmittedState> conditions:($submitState == "submitted")
--<Col-ResultPanel "resultPanel"> style:"neutral|soft|solid|passive" padding:"24px" gap:"18px"
---<Row-ResultHead "resultHead"> width:"100%" justify-content:"space-between" align-items:"flex-start" gap:"12px" flex-wrap:"wrap"
----<Col-ResultCopy "resultCopy"> gap:"6px" flex:"1"
-----<Text-ResultTitle "resultTitle"> value:"结果统计" style:"contrast" font-size:"26px" font-weight:"700"
-----<Text-ResultDesc "resultDesc"> value:"提交成功后会展示各选项的分布条，便于检查后端统计与前端条件渲染。" style:"body" sk.fg:"#64748B" line-height:"1.7"
----<Button-ContinueVote "continueVoteButton"> value:"继续投下一票" style:"neutral|outlined|default|md|actionable"
---<Row-ResultStats "resultStats"> gap:"16px" flex-wrap:"wrap"
----<Component-VoteStatCard "resultTotalCard"> label:"总票数" value:("" + $summary.totalVotes) helper:"本轮投票的总响应数" accentColor:"#2563EB" flex:"1 1 220px" min-width:"220px"
----<Component-VoteStatCard "resultSingleCard"> label:"单选热门" value:$summary.topSingleLabel helper:"单选题中当前票数最高的答案" accentColor:"#F59E0B" flex:"1 1 220px" min-width:"220px"
----<Component-VoteStatCard "resultMultiCard"> label:"多选热门" value:$summary.topMultiLabel helper:"多选题中当前出现最多的因素" accentColor:"#10B981" flex:"1 1 220px" min-width:"220px"
---<If-HasResults> conditions:($resultBoard.singleOptions.length > 0 || $resultBoard.multiOptions.length > 0)
----<Col-ResultBoard "resultBoardPanel"> gap:"18px"
-----<Col-SingleResultPanel "singleResultPanel"> style:"neutral|soft|subtle|passive" padding:"18px" gap:"14px"
------<Row-BlockHead "singleBlockHead"> justify-content:"space-between" align-items:"center" gap:"12px" flex-wrap:"wrap"
-------<Text-SingleBlockTitle "singleBlockTitle"> value:"单选分布" style:"contrast" font-size:"22px" font-weight:"700"
-------<Text-SingleBlockHint "singleBlockHint"> value:"每一条横向分布条都来自后端统计结果。" style:"body" sk.fg:"#64748B"
------<For-SingleResultRows> sourceArray:$resultBoard.singleOptions loopVar:[_item0,_index0]
-------<Col-SingleResultRow "singleResultRow"> gap:"8px"
--------<Row-SingleMeta "singleMeta"> justify-content:"space-between" align-items:"center" gap:"12px"
---------<Text-SingleLabel "singleLabel"> value:_item0.label style:"body" font-weight:"600"
---------<Text-SingleCount "singleCount"> value:(("" + _item0.count) + " 票") style:"body" font-weight:"700" sk.fg:"#0F172A"
--------<Row-SingleTrack "singleTrack"> width:"100%" height:"12px" overflow:"hidden" sk.bg:"#E2E8F0" sk.radius:"9999px"
---------<Row-SingleFill "singleFill"> height:"100%" width:("" + _item0.percent + "%") sk.bg:(_item0.isTop ? "#2563EB" : "#93C5FD") sk.radius:"9999px"
--------<Text-SinglePercent "singlePercent"> value:(("" + _item0.percent) + "%") style:"caption"
-----<Col-MultiResultPanel "multiResultPanel"> style:"neutral|soft|subtle|passive" padding:"18px" gap:"14px"
------<Row-BlockHead "multiBlockHead"> justify-content:"space-between" align-items:"center" gap:"12px" flex-wrap:"wrap"
-------<Text-MultiBlockTitle "multiBlockTitle"> value:"多选分布" style:"contrast" font-size:"22px" font-weight:"700"
-------<Text-MultiBlockHint "multiBlockHint"> value:"多选统计按所有勾选次数汇总。" style:"body" sk.fg:"#64748B"
------<For-MultiResultRows> sourceArray:$resultBoard.multiOptions loopVar:[_item1,_index1]
-------<Col-MultiResultRow "multiResultRow"> gap:"8px"
--------<Row-MultiMeta "multiMeta"> justify-content:"space-between" align-items:"center" gap:"12px"
---------<Text-MultiLabel "multiLabel"> value:_item1.label style:"body" font-weight:"600"
---------<Text-MultiCount "multiCount"> value:(("" + _item1.count) + " 次") style:"body" font-weight:"700" sk.fg:"#0F172A"
--------<Row-MultiTrack "multiTrack"> width:"100%" height:"12px" overflow:"hidden" sk.bg:"#E2E8F0" sk.radius:"9999px"
---------<Row-MultiFill "multiFill"> height:"100%" width:("" + _item1.percent + "%") sk.bg:(_item1.isTop ? "#10B981" : "#A7F3D0") sk.radius:"9999px"
--------<Text-MultiPercent "multiPercent"> value:(("" + _item1.percent) + "%") style:"caption"
---<Row-ResultActionRow "resultActionRow"> justify-content:"space-between" align-items:"center" gap:"12px" flex-wrap:"wrap"
----<Text-ResultHint "resultHint"> value:"点击继续按钮后，表单会重置为待作答状态。" style:"body" sk.fg:"#64748B"
----<Button-ContinueVoteBottom "continueVoteBottomButton"> value:"继续投下一票" style:"neutral|outlined|default|md|actionable"
-<If-FormState> conditions:($submitState != "submitted")
--<Col-FormPanel "formPanel"> style:"neutral|soft|solid|passive" padding:"24px" gap:"18px"
---<Row-FormHead "formHead"> width:"100%" justify-content:"space-between" align-items:"flex-start" gap:"12px" flex-wrap:"wrap"
----<Col-FormCopy "formCopy"> gap:"6px" flex:"1"
-----<Text-FormTitle "formTitle"> value:"投票填写区" style:"contrast" font-size:"26px" font-weight:"700"
-----<Text-FormDesc "formDesc"> value:"提交前显示填写进度条，完成两道必答题后即可提交。" style:"body" sk.fg:"#64748B" line-height:"1.7"
----<Button-SubmitVote "submitVoteButton"> value:$submitButtonLabel style:"primary|filled|default|md|actionable" disabled:(!$canSubmit)
---<Row-ProgressHead "progressHead"> justify-content:"space-between" align-items:"center" gap:"12px" flex-wrap:"wrap"
----<Text-ProgressLabel "progressLabel"> value:"填写进度" style:"caption"
----<Text-ProgressValue "progressValue"> value:$progressLabel style:"contrast" font-size:"22px" font-weight:"700"
---<Row-ProgressTrack "progressTrack"> width:"100%" height:"14px" overflow:"hidden" sk.bg:"#E2E8F0" sk.radius:"9999px"
----<Row-ProgressFill "progressFill"> height:"100%" width:("" + $progressPercent + "%") sk.bg:"#2563EB" sk.radius:"9999px"
---<Text-ProgressHint "progressHint"> value:$boardHint style:"body" sk.fg:"#64748B"
---<If-LoadingState> conditions:$isLoading
----<Row-LoadingState "loadingState"> style:"info|tonal|soft|passive" padding:"16px" align-items:"center" justify-content:"center"
-----<Text-LoadingText "loadingText"> value:"正在加载或提交中..." style:"contrast" font-weight:"600"
---<If-HasQuestions> conditions:$hasQuestions
----<Col-QuestionsWrap "questionsWrap"> gap:"18px"
-----<Col-SingleQuestionCard "singleQuestionCard"> style:"neutral|soft|subtle|passive" padding:"18px" gap:"14px"
------<Row-SingleQuestionHead "singleQuestionHead"> justify-content:"space-between" align-items:"center" gap:"12px" flex-wrap:"wrap"
-------<Text-SingleQuestionTitle "singleQuestionTitle"> value:$singleQuestionTitle style:"contrast" font-size:"22px" font-weight:"700"
-------<Text-SingleQuestionBadge "singleQuestionBadge"> value:$singleRequiredLabel style:"primary|tonal|pill|body" padding:"8px 12px" width:"fit-content" sk.bg:"#DBEAFE" sk.fg:"#1D4ED8" font-weight:"600"
------<Text-SingleQuestionDesc "singleQuestionDesc"> value:"请选择一个最想参加的活动类型。" style:"body" sk.fg:"#64748B" line-height:"1.7"
------<Row-SingleOptions "singleOptions"> gap:"10px" flex-wrap:"wrap"
-------<Button-SingleBoardgame "singleBoardgameButton"> value:"桌游局" style:"neutral|ghost|pill|sm|selectable" sk.bg:($selectedSingle == "boardgame" ? "#DBEAFE" : "#FFFFFF") sk.fg:($selectedSingle == "boardgame" ? "#2563EB" : "#0F172A") sk.borderColor:($selectedSingle == "boardgame" ? "#93C5FD" : "#E2E8F0") sk.borderWidth:"1px"
-------<Button-SingleHiking "singleHikingButton"> value:"徒步" style:"neutral|ghost|pill|sm|selectable" sk.bg:($selectedSingle == "hiking" ? "#DBEAFE" : "#FFFFFF") sk.fg:($selectedSingle == "hiking" ? "#2563EB" : "#0F172A") sk.borderColor:($selectedSingle == "hiking" ? "#93C5FD" : "#E2E8F0") sk.borderWidth:"1px"
-------<Button-SingleMovie "singleMovieButton"> value:"电影" style:"neutral|ghost|pill|sm|selectable" sk.bg:($selectedSingle == "movie" ? "#DBEAFE" : "#FFFFFF") sk.fg:($selectedSingle == "movie" ? "#2563EB" : "#0F172A") sk.borderColor:($selectedSingle == "movie" ? "#93C5FD" : "#E2E8F0") sk.borderWidth:"1px"
-------<Button-SingleCitywalk "singleCitywalkButton"> value:"城市漫游" style:"neutral|ghost|pill|sm|selectable" sk.bg:($selectedSingle == "citywalk" ? "#DBEAFE" : "#FFFFFF") sk.fg:($selectedSingle == "citywalk" ? "#2563EB" : "#0F172A") sk.borderColor:($selectedSingle == "citywalk" ? "#93C5FD" : "#E2E8F0") sk.borderWidth:"1px"
------<If-SingleValidation> conditions:($showValidation && $selectedSingle.trim().length == 0)
-------<Text-SingleValidation "singleValidation"> value:"单选题为必答，请先选择一个答案。" style:"body" sk.fg:"#B91C1C"
-----<Col-MultiQuestionCard "multiQuestionCard"> style:"neutral|soft|subtle|passive" padding:"18px" gap:"14px"
------<Row-MultiQuestionHead "multiQuestionHead"> justify-content:"space-between" align-items:"center" gap:"12px" flex-wrap:"wrap"
-------<Text-MultiQuestionTitle "multiQuestionTitle"> value:$multiQuestionTitle style:"contrast" font-size:"22px" font-weight:"700"
-------<Text-MultiQuestionBadge "multiQuestionBadge"> value:$multiRequiredLabel style:"primary|tonal|pill|body" padding:"8px 12px" width:"fit-content" sk.bg:"#DBEAFE" sk.fg:"#1D4ED8" font-weight:"600"
------<Text-MultiQuestionDesc "multiQuestionDesc"> value:"可以多选，越接近你的真实决策因素越好。" style:"body" sk.fg:"#64748B" line-height:"1.7"
------<Row-MultiOptions "multiOptions"> gap:"10px" flex-wrap:"wrap"
-------<Button-MultiBudget "multiBudgetButton"> value:"预算友好" style:"neutral|ghost|pill|sm|selectable" sk.bg:($selectedMulti.includes("budget") ? "#ECFDF5" : "#FFFFFF") sk.fg:($selectedMulti.includes("budget") ? "#047857" : "#0F172A") sk.borderColor:($selectedMulti.includes("budget") ? "#A7F3D0" : "#E2E8F0") sk.borderWidth:"1px"
-------<Button-MultiSocial "multiSocialButton"> value:"社交氛围" style:"neutral|ghost|pill|sm|selectable" sk.bg:($selectedMulti.includes("social") ? "#ECFDF5" : "#FFFFFF") sk.fg:($selectedMulti.includes("social") ? "#047857" : "#0F172A") sk.borderColor:($selectedMulti.includes("social") ? "#A7F3D0" : "#E2E8F0") sk.borderWidth:"1px"
-------<Button-MultiNear "multiNearButton"> value:"离家近" style:"neutral|ghost|pill|sm|selectable" sk.bg:($selectedMulti.includes("near") ? "#ECFDF5" : "#FFFFFF") sk.fg:($selectedMulti.includes("near") ? "#047857" : "#0F172A") sk.borderColor:($selectedMulti.includes("near") ? "#A7F3D0" : "#E2E8F0") sk.borderWidth:"1px"
-------<Button-MultiWeekend "multiWeekendButton"> value:"周末举办" style:"neutral|ghost|pill|sm|selectable" sk.bg:($selectedMulti.includes("weekend") ? "#ECFDF5" : "#FFFFFF") sk.fg:($selectedMulti.includes("weekend") ? "#047857" : "#0F172A") sk.borderColor:($selectedMulti.includes("weekend") ? "#A7F3D0" : "#E2E8F0") sk.borderWidth:"1px"
-------<Button-MultiBringFriend "multiBringFriendButton"> value:"可带朋友" style:"neutral|ghost|pill|sm|selectable" sk.bg:($selectedMulti.includes("bringFriend") ? "#ECFDF5" : "#FFFFFF") sk.fg:($selectedMulti.includes("bringFriend") ? "#047857" : "#0F172A") sk.borderColor:($selectedMulti.includes("bringFriend") ? "#A7F3D0" : "#E2E8F0") sk.borderWidth:"1px"
------<If-MultiValidation> conditions:($showValidation && $selectedMulti.length == 0)
-------<Text-MultiValidation "multiValidation"> value:"多选题为必答，请至少选择一个因素。" style:"body" sk.fg:"#B91C1C"
---<Row-ActionRow "actionRow"> justify-content:"space-between" align-items:"center" gap:"12px" flex-wrap:"wrap"
----<Text-ActionHint "actionHint"> value:$boardHint style:"body" sk.fg:"#64748B"
----<Button-SubmitVoteBottom "submitVoteBottomButton"> value:$submitButtonLabel style:"primary|filled|default|md|actionable" disabled:(!$canSubmit)
-<If-NoQuestions> conditions:(!$hasQuestions)
--<Component-VoteEmptyState "emptyState"> title:"暂无投票题目" description:"PollQuestions 表里还没有配置题目，请先检查数据库种子数据。" hint:"加载完成后，这里会显示单选与多选的投票表单。"

# Frontend Event Handlers
<Button-SingleBoardgame "singleBoardgameButton">.@click()
-selectSingleChoice("boardgame") -> _selectResult

<Button-SingleHiking "singleHikingButton">.@click()
-selectSingleChoice("hiking") -> _selectResult

<Button-SingleMovie "singleMovieButton">.@click()
-selectSingleChoice("movie") -> _selectResult

<Button-SingleCitywalk "singleCitywalkButton">.@click()
-selectSingleChoice("citywalk") -> _selectResult

<Button-MultiBudget "multiBudgetButton">.@click()
-toggleMultiChoice("budget") -> _toggleResult

<Button-MultiSocial "multiSocialButton">.@click()
-toggleMultiChoice("social") -> _toggleResult

<Button-MultiNear "multiNearButton">.@click()
-toggleMultiChoice("near") -> _toggleResult

<Button-MultiWeekend "multiWeekendButton">.@click()
-toggleMultiChoice("weekend") -> _toggleResult

<Button-MultiBringFriend "multiBringFriendButton">.@click()
-toggleMultiChoice("bringFriend") -> _toggleResult

<Button-SubmitVote "submitVoteButton">.@click()
-submitVote() -> _submitResult

<Button-SubmitVoteBottom "submitVoteBottomButton">.@click()
-submitVote() -> _submitResultBottom

<Button-ContinueVote "continueVoteButton">.@click()
-resetVoteForm() -> _resetResult

<Button-ContinueVoteBottom "continueVoteBottomButton">.@click()
-resetVoteForm() -> _resetResultBottom

# Frontend Internal Methods
METHOD loadBoard();RETURN {success:BOOL}
-$isLoading = true
-$statusMessage = "正在加载投票板..."
-<ServiceDomain-VoteService "voteService">.GetVoteBoard() -> _result
-$isLoading = false
-IF !_result.success
--$questionList = []
--$summary = {totalVotes:0,topSingleLabel:"-",topMultiLabel:"-",singleVoteCount:0,multiVoteCount:0}
--$resultBoard = {singleOptions:[],multiOptions:[]}
--$statusMessage = _result.message
--RETURN {success:false}
-$questionList = _result.questions
-$summary = _result.summary
-$resultBoard = _result.results
-$submitState = "idle"
-$showValidation = false
-$statusMessage = (_result.message.trim().length > 0 ? _result.message : "投票板已加载")
-RETURN {success:true}

METHOD selectSingleChoice(choiceCode(STRING));RETURN {success:BOOL}
-$selectedSingle = choiceCode
-$showValidation = false
-$statusMessage = "已选择单选答案"
-RETURN {success:true}

METHOD toggleMultiChoice(choiceCode(STRING));RETURN {success:BOOL}
-_index(INT) = $selectedMulti.indexOf(choiceCode)
-IF _index >= 0
--$selectedMulti.splice(_index, 1)
-ELSE
--$selectedMulti.push(choiceCode)
-$showValidation = false
-$statusMessage = "已更新多选因素"
-RETURN {success:true}

METHOD submitVote();RETURN {success:BOOL}
-$showValidation = true
-IF $selectedSingle.trim().length == 0
--$statusMessage = "单选题为必答，请先选择一个答案。"
--RETURN {success:false}
-IF $selectedMulti.length == 0
--$statusMessage = "多选题为必答，请至少选择一个因素。"
--RETURN {success:false}
-$submitState = "submitting"
-$isLoading = true
-<ServiceDomain-VoteService "voteService">.SubmitVote($selectedSingle, $selectedMulti) -> _result
-$isLoading = false
-IF !_result.success
--$submitState = "idle"
--$statusMessage = _result.message
--RETURN {success:false}
-$questionList = _result.questions
-$summary = _result.summary
-$resultBoard = _result.results
-$submitState = "submitted"
-$statusMessage = _result.message
-RETURN {success:true}

METHOD resetVoteForm();RETURN {success:BOOL}
-$selectedSingle = ""
-$selectedMulti = []
-$showValidation = false
-$submitState = "idle"
-$statusMessage = "请继续投下一票"
-RETURN {success:true}

# Frontend Pipeline Funcs
</Section-VoteBoard>
