// VL_VERSION:4.1
// Preview: width:100% height:260px
<Component-VoteEmptyState "root"> padding:"0"

# Frontend Public Props
$title(STRING) = "暂无投票题目"
$description(STRING) = "请先检查题库是否加载，或者补充 PollQuestions 数据。"
$hint(STRING) = ""

# Frontend Public Events

# Frontend Derived Vars

# Frontend Tree
<Col-EmptyShell "emptyShell"> style:"neutral|soft|subtle|passive" padding:"36px" gap:"14px" align-items:"center" justify-content:"center" min-height:"260px"
-<Row-EmptyOrb "emptyOrb"> style:"primary|tonal|pill|passive" width:"64px" height:"64px" align-items:"center" justify-content:"center"
--<Text-EmptyMark "emptyMark"> value:"投" style:"contrast" font-size:"28px" font-weight:"700"
-<Text-EmptyTitle "emptyTitle"> value:$title style:"contrast" font-size:"24px" font-weight:"700" text-align:"center"
-<Text-EmptyDescription "emptyDescription"> value:$description style:"body" text-align:"center" max-width:"420px" line-height:"1.7" sk.fg:"#64748B"
-<If-HasHint> conditions:($hint.trim().length > 0)
--<Text-EmptyHint "emptyHint"> value:$hint style:"caption" text-align:"center"

# Frontend Event Handlers

# Frontend Internal Methods
# Frontend Pipeline Funcs
</Component-VoteEmptyState>
