// VL_VERSION:4.1
// Preview: width:240px height:132px
<Component-HabitStatCard "root"> containerType:col padding:"18px" gap:"8px" style:"subtle|soft|actionable"

# Frontend Public Props
$label(STRING) = ""
$value(STRING) = "0"
$desc(STRING) = ""

# Frontend Public Events

# Frontend Derived Vars

# Frontend Tree
<Text-Label "labelText"> value:$label style:"caption" font-size:"12px"
<Text-Value "valueText"> value:$value style:"contrast" font-size:"30px" font-weight:"700" line-height:"1.1"
<If-HasDesc> conditions:($desc != "")
-<Text-Desc "descText"> value:$desc style:"muted" font-size:"13px"

# Frontend Event Handlers

# Frontend Internal Methods

# Frontend Pipeline Funcs
</Component-HabitStatCard>
