// VL_VERSION:4.1
// Preview: width:100% height:140px
<Component-EmptyStateCard "root"> containerType:col padding:"24px" gap:"10px" align-items:"center" justify-content:"center" style:"subtle|soft|actionable"

# Frontend Public Props
$title(STRING) = ""
$desc(STRING) = ""

# Frontend Public Events

# Frontend Derived Vars

# Frontend Tree
<Text-Title "titleText"> value:$title style:"contrast" font-size:"20px" font-weight:"600"
<Text-Desc "descText"> value:$desc style:"muted" font-size:"14px" text-align:"center"

# Frontend Event Handlers

# Frontend Internal Methods

# Frontend Pipeline Funcs
</Component-EmptyStateCard>
