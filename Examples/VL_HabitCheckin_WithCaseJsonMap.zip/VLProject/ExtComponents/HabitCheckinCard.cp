// VL_VERSION:4.1
// Preview: width:100% height:156px
<Component-HabitCheckinCard "root"> containerType:col padding:"18px" gap:"14px" style:"solid|soft|actionable"

# Frontend Public Props
$habit({id:INT,name:STRING,desc:STRING,icon:STRING,color:STRING,isDoneToday:BOOL,currentStreak:INT,bestStreak:INT,totalCheckins:INT,lastCheckinDate:STRING}) = {id:0,name:"",desc:"",icon:"",color:"#2563EB",isDoneToday:false,currentStreak:0,bestStreak:0,totalCheckins:0,lastCheckinDate:""}

# Frontend Public Events
EVENT @toggle(habitId(INT))

# Frontend Derived Vars
$statusText(STRING) = ($habit.isDoneToday ? "今天已完成" : "今天未完成")
$streakText(STRING) = ("连续 " + String($habit.currentStreak) + " 天")
$bestText(STRING) = ("最佳 " + String($habit.bestStreak) + " 天")
$totalText(STRING) = ("累计 " + String($habit.totalCheckins) + " 次")
$lastDateText(STRING) = (($habit.lastCheckinDate == "") ? "最近打卡: 暂无" : ("最近打卡: " + $habit.lastCheckinDate))

# Frontend Tree
<Row-Head "headRow"> width:"100%" gap:"12px" align-items:"center"
-<Row-IconWrap "iconWrap"> width:"40px" height:"40px" align-items:"center" justify-content:"center" style:"subtle|pill|actionable" sk.bg:$habit.color
--<Text-IconText "iconText"> value:$habit.icon style:"contrast" font-size:"16px" font-weight:"700"
-<Col-InfoWrap "infoWrap"> flex:"1" gap:"4px"
--<Text-Name "nameText"> value:$habit.name style:"contrast" font-size:"18px" font-weight:"600"
--<Text-Desc "descText"> value:$habit.desc style:"muted" font-size:"13px"

<Row-Meta "metaRow"> width:"100%" gap:"10px" align-items:"center"
-<Text-Status "statusText"> value:$statusText style:"caption" font-size:"12px"
-<Text-Streak "streakText"> value:$streakText style:"body" font-size:"13px"
-<Text-Best "bestText"> value:$bestText style:"body" font-size:"13px"
-<Text-Total "totalText"> value:$totalText style:"body" font-size:"13px"

<Row-Action "actionRow"> width:"100%" align-items:"center" justify-content:"space-between"
-<Text-LastDate "lastDateText"> value:$lastDateText style:"muted" font-size:"13px"
-<If-IsDone> conditions:$habit.isDoneToday
--<Button-DoneButton "doneButton"> value:"取消打卡" style:"success|filled|default|md|actionable"
-<If-NotDone> conditions:(!$habit.isDoneToday)
--<Button-TodoButton "todoButton"> value:"立即打卡" style:"primary|filled|default|md|actionable"

# Frontend Event Handlers
<Button-DoneButton "doneButton">.@click()
-@toggle($habit.id)

<Button-TodoButton "todoButton">.@click()
-@toggle($habit.id)

# Frontend Internal Methods

# Frontend Pipeline Funcs
</Component-HabitCheckinCard>
