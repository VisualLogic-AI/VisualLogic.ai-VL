// VL_VERSION:4.1
// Preview: width:100% height:72px
<Component-DateNavigator "root"> containerType:row padding:"16px" gap:"12px" align-items:"center" justify-content:"space-between" style:"solid|soft|actionable"

# Frontend Public Props
$displayDate(STRING) = ""
$canGoNext(BOOL) = false

# Frontend Public Events
EVENT @prevDay()
EVENT @nextDay()
EVENT @goToday()

# Frontend Derived Vars

# Frontend Tree
<Button-PrevButton "prevButton"> value:"前一天" style:"neutral|outlined|default|md|actionable"
<Text-DateText "dateText"> value:$displayDate style:"contrast" font-size:"18px" font-weight:"600" text-align:"center" width:"220px"
<Row-ActionGroup "actionGroup"> gap:"10px" align-items:"center"
-<Button-TodayButton "todayButton"> value:"回到今天" style:"neutral|ghost|default|md|actionable"
-<Button-NextButton "nextButton"> value:"后一天" disabled:(!$canGoNext) style:"primary|filled|default|md|actionable"

# Frontend Event Handlers
<Button-PrevButton "prevButton">.@click()
-@prevDay()

<Button-TodayButton "todayButton">.@click()
-@goToday()

<Button-NextButton "nextButton">.@click()
-@nextDay()

# Frontend Internal Methods

# Frontend Pipeline Funcs
</Component-DateNavigator>
