# Generation Notes

- 所有 VL 文件均使用 `// VL_VERSION:4.1`
- Theme 采用 Enterprise 风格亮色体系
- 日期偏移通过 `TIMESTAMP.unixS()` 与 `setUnixS()` 完成
- 连续打卡计算放在 `Services/HabitService.vs`
- `Apps/HabitCheckinApp.vx` 仅负责页面与 Section 装配
- `Sections/HabitDashboard.sc` 负责前端业务逻辑与服务调用
- `ExtComponents/` 中的组件保持纯 UI 角色
