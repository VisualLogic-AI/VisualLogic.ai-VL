# HabitCheckin Requirements

- 应用主题：习惯打卡
- 重点验证：日期处理、布尔状态切换、统计展示、连续打卡逻辑
- 页面结构：
  - 顶部说明区
  - 日期导航
  - 统计卡片
  - 习惯列表
- 数据对象：
  - `Habits`
  - `HabitCheckinLogs`
- 服务入口：
  - `GetDashboard(targetDate)`
  - `ToggleHabitCheckin(habitId, targetDate)`
  - `SeedDemoData()`
