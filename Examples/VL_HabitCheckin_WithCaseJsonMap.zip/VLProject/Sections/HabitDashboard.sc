// VL_VERSION:4.1
// Preview: width:100% min-height:760px
<Section-HabitDashboard "root"> containerType:col padding:"24px" gap:"18px"

# Frontend Public Props

# Frontend Public Events
EVENT @dateChanged(targetDate(STRING))
EVENT @habitToggled(habitId(INT),isDoneToday(BOOL))

# Frontend Public Methods
METHOD LoadForDate(targetDate(STRING)); RETURN {success:BOOL}
-syncTodayString() -> _todayString
-$currentDate = targetDate
-loadDashboard() -> _result
-RETURN _result

# Frontend Global Vars
$currentDate(STRING) = "2026-04-01"
$todayString(STRING) = "2026-04-01"
$habits([{id:INT,name:STRING,desc:STRING,icon:STRING,color:STRING,isDoneToday:BOOL,currentStreak:INT,bestStreak:INT,totalCheckins:INT,lastCheckinDate:STRING}]) = []
$summary({doneCount:INT,activeCount:INT,longestStreak:INT,totalCheckins:INT}) = {doneCount:0,activeCount:0,longestStreak:0,totalCheckins:0}
$isLoading(BOOL) = false

# Frontend Derived Vars
$canGoNext(BOOL) = ($currentDate != $todayString)
$dateTitle(STRING) = ("目标日期: " + $currentDate)

# Frontend Tree
<ServiceDomain-HabitService "habitService">
-<Service-GetDashboard> params:(targetDate(STRING)) returns:(success(BOOL),summary({doneCount:INT,activeCount:INT,longestStreak:INT,totalCheckins:INT}),habits([{}]))
-<Service-ToggleHabitCheckin> params:(habitId(INT),targetDate(STRING)) returns:(success(BOOL),isDoneToday(BOOL),currentStreak(INT),bestStreak(INT),totalCheckins(INT))
-<Service-SeedDemoData> returns:(success(BOOL))

<Col-Hero "heroBlock"> gap:"8px" padding:"20px" style:"solid|soft|actionable"
-<Text-Title "titleText"> value:"习惯打卡" style:"contrast" font-size:"32px" font-weight:"700" line-height:"1.1"
-<Text-Subtitle "subtitleText"> value:"聚焦日期处理、布尔切换、统计展示与连续打卡逻辑的测试场景。" style:"muted" font-size:"14px"
-<Text-DateTitle "dateTitleText"> value:$dateTitle style:"body" font-size:"14px"

<Component-DateNavigator "dateNavigator"> height:"72px" displayDate:$currentDate canGoNext:$canGoNext

<Row-StatsRow "statsRow"> width:"100%" gap:"16px"
-<Component-HabitStatCard "doneStat"> flex:"1" label:"今日完成数" value:String($summary.doneCount) desc:"目标日期已完成的习惯数量"
-<Component-HabitStatCard "activeStat"> flex:"1" label:"活跃习惯数" value:String($summary.activeCount) desc:"当前参与统计的习惯数量"
-<Component-HabitStatCard "bestStat"> flex:"1" label:"最长连续天数" value:String($summary.longestStreak) desc:"所有习惯中的历史最佳 streak"
-<Component-HabitStatCard "totalStat"> flex:"1" label:"总打卡次数" value:String($summary.totalCheckins) desc:"所有习惯累计打卡记录"

<If-IsLoading> conditions:$isLoading
-<Col-LoadingBlock "loadingBlock"> gap:"8px" padding:"20px" style:"subtle|soft|actionable"
--<Text-LoadingTitle "loadingTitle"> value:"加载中..." style:"contrast" font-size:"18px" font-weight:"600"
--<Text-LoadingDesc "loadingDesc"> value:"正在同步目标日期的习惯数据与统计结果。" style:"muted" font-size:"13px"

<If-HasHabits> conditions:(!$isLoading && $habits.length > 0)
-<Col-HabitList "habitList"> gap:"14px"
--<For-HabitItems> sourceArray:$habits loopVar:[_item0, _index0]
---<Component-HabitCheckinCard "habitCard"> habit:_item0

<If-IsEmpty> conditions:(!$isLoading && $habits.length == 0)
-<Component-EmptyStateCard "emptyStateCard"> title:"暂无习惯" desc:"可以先通过服务层 SeedDemoData 注入演示数据，或者在数据库中增加新的习惯。" 

# Frontend Event Handlers
<Component-DateNavigator "dateNavigator">.@prevDay()
-syncTodayString() -> _todayString
-changeDate(-1) -> _result
-IF _result.success
--@dateChanged($currentDate)

<Component-DateNavigator "dateNavigator">.@nextDay()
-syncTodayString() -> _todayString
-IF !$canGoNext
--RETURN
-changeDate(1) -> _result
-IF _result.success
--@dateChanged($currentDate)

<Component-DateNavigator "dateNavigator">.@goToday()
-syncTodayString() -> _todayString
-$currentDate = $todayString
-loadDashboard() -> _result
-IF _result.success
--@dateChanged($currentDate)

<Component-HabitCheckinCard "habitCard">.@toggle(habitId)
-toggleHabitDone(habitId) -> _result
-IF _result.success
--@habitToggled(habitId, _result.isDoneToday)

# Frontend Internal Methods
METHOD syncTodayString(); RETURN STRING
-$todayString = SYSENV.currentTime.format("YYYY-MM-DD")
-RETURN $todayString

METHOD loadDashboard(); RETURN {success:BOOL}
-$isLoading = true
-<ServiceDomain-HabitService "habitService">.SeedDemoData() -> _seedResult
-<ServiceDomain-HabitService "habitService">.GetDashboard($currentDate) -> _result
-$isLoading = false
-IF !_result.success
--RETURN {success:false}
-$summary = _result.summary
-$habits = _result.habits
-RETURN {success:true}

METHOD changeDate(offsetDays(INT)); RETURN {success:BOOL}
-_time(TIMESTAMP) = $currentDate
-_nextTime(TIMESTAMP) = $currentDate
-_nextUnix(INT) = (_time.unixS() + (offsetDays * 86400))
-_nextTime.setUnixS(_nextUnix)
-$currentDate = _nextTime.format("YYYY-MM-DD")
-loadDashboard() -> _result
-RETURN _result

METHOD toggleHabitDone(habitId(INT)); RETURN {success:BOOL,isDoneToday:BOOL}
-<ServiceDomain-HabitService "habitService">.ToggleHabitCheckin(habitId, $currentDate) -> _toggleResult
-IF !_toggleResult.success
--RETURN {success:false,isDoneToday:false}
-loadDashboard() -> _dashboardResult
-IF !_dashboardResult.success
--RETURN {success:false,isDoneToday:_toggleResult.isDoneToday}
-RETURN {success:true,isDoneToday:_toggleResult.isDoneToday}

# Frontend Pipeline Funcs
</Section-HabitDashboard>
