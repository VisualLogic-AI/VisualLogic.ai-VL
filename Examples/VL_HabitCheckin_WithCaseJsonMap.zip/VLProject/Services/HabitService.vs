// VL_VERSION:4.1
<ServiceDomain-HabitService>

# Backend Tree
<VirtualTable-Habits "habitTable"> sourceTable:Habits
-<Field-name> type:STRING
-<Field-desc> type:STRING
-<Field-icon> type:STRING
-<Field-color> type:STRING
-<Field-active> type:BOOL
-<Field-createdDate> type:STRING
-<Field-lastCheckinDate> type:STRING
-<Field-currentStreak> type:INT
-<Field-bestStreak> type:INT
-<Field-totalCheckins> type:INT

<VirtualTable-HabitCheckinLogs "logTable"> sourceTable:HabitCheckinLogs
-<Field-habitId> type:INT
-<Field-checkinDate> type:STRING
-<Field-checkinAt> type:TIMESTAMP

# Services
SERVICE GetDashboard(targetDate(STRING));RETURN {success:BOOL,summary:{doneCount:INT,activeCount:INT,longestStreak:INT,totalCheckins:INT},habits:[{}]}
-ensureSeedData() -> _seedResult
-buildDashboard(targetDate) -> _dashboard
-RETURN {success:true,summary:_dashboard.summary,habits:_dashboard.habits}

SERVICE ToggleHabitCheckin(habitId(INT),targetDate(STRING));RETURN {success:BOOL,isDoneToday:BOOL,currentStreak:INT,bestStreak:INT,totalCheckins:INT}
-ensureSeedData() -> _seedResult
-isHabitCheckedOnDate(habitId, targetDate) -> _alreadyDone
-IF !_alreadyDone
--<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:habitId,checkinDate:targetDate,checkinAt:targetDate}) -> _insertResult
-IF _alreadyDone
--<VirtualTable-HabitCheckinLogs "logTable">.delete([["habitId","eq",habitId],["checkinDate","eq",targetDate]], 1) -> _deleteResult
-refreshHabitMetrics(habitId, targetDate) -> _metrics
-RETURN {success:true,isDoneToday:(!_alreadyDone),currentStreak:_metrics.currentStreak,bestStreak:_metrics.bestStreak,totalCheckins:_metrics.totalCheckins}

SERVICE SeedDemoData();RETURN {success:BOOL}
-ensureSeedData() -> _result
-RETURN {success:_result.success}

# Backend Event Handlers
# Transactions

# Backend Internal Methods
METHOD ensureSeedData(); RETURN {success:BOOL}
-<VirtualTable-Habits "habitTable">.count(null) -> _habitCount
-IF _habitCount.count > 0
--RETURN {success:true}
-<VirtualTable-Habits "habitTable">.insert({name:"晨间拉伸",desc:"起床后完成 10 分钟拉伸",icon:"S",color:"#2563EB",active:true,createdDate:"2026-03-20",lastCheckinDate:"2026-04-01",currentStreak:4,bestStreak:7,totalCheckins:9}) -> _habit1
-<VirtualTable-Habits "habitTable">.insert({name:"阅读 30 分钟",desc:"每天晚间阅读并记录进度",icon:"R",color:"#10B981",active:true,createdDate:"2026-03-18",lastCheckinDate:"2026-03-31",currentStreak:2,bestStreak:5,totalCheckins:8}) -> _habit2
-<VirtualTable-Habits "habitTable">.insert({name:"饮水 8 杯",desc:"保持全天饮水节奏",icon:"W",color:"#F59E0B",active:true,createdDate:"2026-03-15",lastCheckinDate:"2026-04-01",currentStreak:6,bestStreak:6,totalCheckins:12}) -> _habit3
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit1.dataId,checkinDate:"2026-03-29",checkinAt:"2026-03-29 07:30:00"}) -> _log1
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit1.dataId,checkinDate:"2026-03-30",checkinAt:"2026-03-30 07:32:00"}) -> _log2
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit1.dataId,checkinDate:"2026-03-31",checkinAt:"2026-03-31 07:31:00"}) -> _log3
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit1.dataId,checkinDate:"2026-04-01",checkinAt:"2026-04-01 07:29:00"}) -> _log4
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit2.dataId,checkinDate:"2026-03-25",checkinAt:"2026-03-25 21:00:00"}) -> _log5
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit2.dataId,checkinDate:"2026-03-26",checkinAt:"2026-03-26 21:10:00"}) -> _log6
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit2.dataId,checkinDate:"2026-03-30",checkinAt:"2026-03-30 21:05:00"}) -> _log7
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit2.dataId,checkinDate:"2026-03-31",checkinAt:"2026-03-31 21:08:00"}) -> _log8
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit3.dataId,checkinDate:"2026-03-27",checkinAt:"2026-03-27 20:00:00"}) -> _log9
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit3.dataId,checkinDate:"2026-03-28",checkinAt:"2026-03-28 20:00:00"}) -> _log10
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit3.dataId,checkinDate:"2026-03-29",checkinAt:"2026-03-29 20:00:00"}) -> _log11
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit3.dataId,checkinDate:"2026-03-30",checkinAt:"2026-03-30 20:00:00"}) -> _log12
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit3.dataId,checkinDate:"2026-03-31",checkinAt:"2026-03-31 20:00:00"}) -> _log13
-<VirtualTable-HabitCheckinLogs "logTable">.insert({habitId:_habit3.dataId,checkinDate:"2026-04-01",checkinAt:"2026-04-01 20:00:00"}) -> _log14
-RETURN {success:true}

METHOD buildDashboard(targetDate(STRING)); RETURN {summary:{doneCount:INT,activeCount:INT,longestStreak:INT,totalCheckins:INT},habits:[{}]}
-<VirtualTable-Habits "habitTable">.select([["active","eq",true]],[["_id","asc"]],[0,100],null) -> _habitResult
-_doneCount(INT) = 0
-_activeCount(INT) = 0
-_longestStreak(INT) = 0
-_totalCheckins(INT) = 0
-_habits([{}]) = []
-FOR (_habit0, _index0) IN _habitResult.dataArray
--isHabitCheckedOnDate(_habit0._id, targetDate) -> _isDoneToday
--IF _isDoneToday
---_doneCount = _doneCount + 1
--IF _habit0.active
---_activeCount = _activeCount + 1
--_totalCheckins = _totalCheckins + _habit0.totalCheckins
--IF _habit0.bestStreak > _longestStreak
---_longestStreak = _habit0.bestStreak
--_habitItem({id:INT,name:STRING,desc:STRING,icon:STRING,color:STRING,isDoneToday:BOOL,currentStreak:INT,bestStreak:INT,totalCheckins:INT,lastCheckinDate:STRING}) = {id:_habit0._id,name:_habit0.name,desc:_habit0.desc,icon:_habit0.icon,color:_habit0.color,isDoneToday:_isDoneToday,currentStreak:_habit0.currentStreak,bestStreak:_habit0.bestStreak,totalCheckins:_habit0.totalCheckins,lastCheckinDate:_habit0.lastCheckinDate}
--_habits.push(_habitItem)
-RETURN {summary:{doneCount:_doneCount,activeCount:_activeCount,longestStreak:_longestStreak,totalCheckins:_totalCheckins},habits:_habits}

METHOD isHabitCheckedOnDate(habitId(INT), targetDate(STRING)); RETURN BOOL
-<VirtualTable-HabitCheckinLogs "logTable">.count([["habitId","eq",habitId],["checkinDate","eq",targetDate]]) -> _countResult
-RETURN (_countResult.count > 0)

METHOD shiftDate(baseDate(STRING), offsetDays(INT)); RETURN STRING
-_time(TIMESTAMP) = baseDate
-_nextTime(TIMESTAMP) = baseDate
-_nextUnix(INT) = (_time.unixS() + (offsetDays * 86400))
-_nextTime.setUnixS(_nextUnix)
-RETURN _nextTime.format("YYYY-MM-DD")

METHOD calcCurrentStreak(habitId(INT), targetDate(STRING)); RETURN INT
-isHabitCheckedOnDate(habitId, targetDate) -> _targetChecked
-IF !_targetChecked
--RETURN 0
-_streak(INT) = 0
-_keepGoing(BOOL) = true
-FOR (_dayOffset(INT) = 0; _dayOffset < 365; _dayOffset++)
--IF _keepGoing
---shiftDate(targetDate, (-_dayOffset)) -> _scanDate
---isHabitCheckedOnDate(habitId, _scanDate) -> _checked
---IF _checked
----_streak = _streak + 1
---IF !_checked
----_keepGoing = false
-RETURN _streak

METHOD calcBestStreak(habitId(INT)); RETURN INT
-<VirtualTable-HabitCheckinLogs "logTable">.select([["habitId","eq",habitId]],[["checkinDate","asc"]],[0,500],null) -> _logResult
-IF _logResult.dataArray.length == 0
--RETURN 0
-_best(INT) = 0
-_current(INT) = 0
-_prevDate(STRING) = ""
-FOR (_item0, _index0) IN _logResult.dataArray
--IF _index0 == 0
---_current = 1
---_best = 1
---_prevDate = _item0.checkinDate
--IF _index0 > 0
---shiftDate(_prevDate, 1) -> _expectedDate
---IF _item0.checkinDate == _expectedDate
----_current = _current + 1
---IF _item0.checkinDate != _expectedDate
----_current = 1
---IF _current > _best
----_best = _current
---_prevDate = _item0.checkinDate
-RETURN _best

METHOD getLastCheckinDate(habitId(INT)); RETURN STRING
-<VirtualTable-HabitCheckinLogs "logTable">.select([["habitId","eq",habitId]],[["checkinDate","desc"]],[0,1],null) -> _logResult
-IF _logResult.dataArray.length == 0
--RETURN ""
-RETURN _logResult.dataArray[0].checkinDate

METHOD refreshHabitMetrics(habitId(INT), targetDate(STRING)); RETURN {currentStreak:INT,bestStreak:INT,totalCheckins:INT,lastCheckinDate:STRING}
-calcCurrentStreak(habitId, targetDate) -> _currentStreak
-calcBestStreak(habitId) -> _bestStreak
-getLastCheckinDate(habitId) -> _lastCheckinDate
-<VirtualTable-HabitCheckinLogs "logTable">.count([["habitId","eq",habitId]]) -> _totalResult
-<VirtualTable-Habits "habitTable">.update([["_id","eq",habitId]],[["lastCheckinDate","set",_lastCheckinDate],["currentStreak","set",_currentStreak],["bestStreak","set",_bestStreak],["totalCheckins","set",_totalResult.count]], 1) -> _updateResult
-RETURN {currentStreak:_currentStreak,bestStreak:_bestStreak,totalCheckins:_totalResult.count,lastCheckinDate:_lastCheckinDate}

# Backend Pipeline Funcs
</ServiceDomain-HabitService>
