// VL_VERSION:4.1
// Preview: width:100% min-height:960px
<Section-ShoppingBoard "root"> gap:"24px"

# Frontend Public Props

# Frontend Public Events

# Frontend Public Methods
METHOD LoadBoard();RETURN {success:BOOL}
-loadBoard() -> _result
-RETURN {success:_result.success}

# Frontend Global Vars
$itemList([{_id:INT,name:STRING,category:STRING,quantity:INT,unitPrice:FLOAT,isBought:BOOL,note:STRING,subtotal:FLOAT}]) = []
$categoryTabs([{name:STRING,count:INT,boughtCount:INT}]) = []
$categoryFilter(STRING) = "all"
$statusFilter(STRING) = "all"
$draftName(STRING) = ""
$draftCategory(STRING) = "蔬果"
$draftQuantity(STRING) = "1"
$draftUnitPrice(STRING) = "0"
$draftNote(STRING) = ""
$isLoading(BOOL) = false
$errorMessage(STRING) = ""
$summary({totalItems:INT,pendingItems:INT,boughtItems:INT,estimatedTotal:FLOAT,pendingTotal:FLOAT}) = {totalItems:0,pendingItems:0,boughtItems:0,estimatedTotal:0,pendingTotal:0}

# Frontend Derived Vars
$hasItems(BOOL) = ($itemList.length > 0)
$canCreate(BOOL) = ($draftName.trim().length > 0 && !isNaN(Number($draftQuantity.trim())) && Number($draftQuantity.trim()) >= 1 && Number($draftQuantity.trim()) == Math.floor(Number($draftQuantity.trim())) && !isNaN(Number($draftUnitPrice.trim())) && Number($draftUnitPrice.trim()) >= 0)
$currentCategoryLabel(STRING) = ($categoryFilter == "all" ? "全部分类" : $categoryFilter)
$currentStatusLabel(STRING) = ($statusFilter == "all" ? "全部状态" : ($statusFilter == "pending" ? "未买" : "已买"))
$estimatedTotalLabel(STRING) = ("¥" + $summary.estimatedTotal.toFixed(2))
$pendingTotalLabel(STRING) = ("¥" + $summary.pendingTotal.toFixed(2))
$currentViewTotal(FLOAT) = $itemList.reduce((acc, item) => acc + item.subtotal, 0)
$currentViewTotalLabel(STRING) = ("¥" + $currentViewTotal.toFixed(2))
$listHint(STRING) = ((($currentCategoryLabel + " · ") + $currentStatusLabel) + (" · 当前视图合计 " + $currentViewTotalLabel))

# Frontend Tree
<ServiceDomain-ShoppingList "shoppingService">
-<Service-GetBoard> params:(categoryFilter(STRING),statusFilter(STRING)) returns:(success(BOOL),data([{}]),summary({}),categories([{}]),message(STRING))
-<Service-CreateItem> params:(name(STRING),category(STRING),quantity(INT),unitPrice(FLOAT),note(STRING)) returns:(success(BOOL),message(STRING),dataId(INT))
-<Service-ToggleBought> params:(itemId(INT),nextBought(BOOL)) returns:(success(BOOL),message(STRING))
-<Service-AdjustQuantity> params:(itemId(INT),delta(INT)) returns:(success(BOOL),message(STRING))
-<Service-DeleteItem> params:(itemId(INT)) returns:(success(BOOL),message(STRING))

<Col-BoardRoot "boardRoot"> gap:"24px"
-<Col-OverviewPanel "overviewPanel"> style:"neutral|soft|elevated|passive" padding:"28px" gap:"20px"
--<Row-OverviewHead "overviewHead"> width:"100%" justify-content:"space-between" align-items:"flex-start" gap:"18px"
---<Col-TitleBlock "titleBlock"> gap:"10px" flex:"1"
----<Text-Overline "overline"> value:"SHOPPING LIST" style:"caption"
----<Text-BoardTitle "boardTitle"> value:"把采购事项拆成清晰的数量、分类和金额。" style:"contrast" font-size:"34px" font-weight:"700" line-height:"1.15"
----<Text-BoardSubtitle "boardSubtitle"> value:"支持列表增删、数量步进、分类筛选、已买状态切换和金额合计，适合验证表单与列表类 VL 场景。" style:"body" line-height:"1.7" sk.fg:"#64748B"
---<Col-FilterStatusPanel "filterStatusPanel"> style:"neutral|soft|solid|passive" padding:"16px" gap:"8px" min-width:"300px"
----<Text-FilterStatusLabel "filterStatusLabel"> value:"当前筛选" style:"caption"
----<Text-FilterStatusValue "filterStatusValue"> value:(($currentCategoryLabel + " · ") + $currentStatusLabel) style:"contrast" font-size:"20px" font-weight:"700"
----<Text-FilterStatusHint "filterStatusHint"> value:("当前列表金额 " + $currentViewTotalLabel) style:"body" sk.fg:"#64748B"
--<Row-StatsRow "statsRow"> gap:"16px"
---<Component-ShoppingSummaryCard "totalCard"> width:"240px" label:"清单总数" value:("" + $summary.totalItems) helper:"所有待采购与已买商品条目。" accentColor:"#2563EB"
---<Component-ShoppingSummaryCard "pendingCard"> width:"240px" label:"未买商品" value:("" + $summary.pendingItems) helper:("待购金额 " + $pendingTotalLabel) accentColor:"#F59E0B"
---<Component-ShoppingSummaryCard "boughtCard"> width:"240px" label:"已买商品" value:("" + $summary.boughtItems) helper:"切换状态后会实时更新计数。" accentColor:"#10B981"
---<Component-ShoppingSummaryCard "budgetCard"> width:"240px" label:"预算合计" value:$estimatedTotalLabel helper:"按数量 x 单价自动汇总。" accentColor:"#EF4444"
-<Col-ComposerPanel "composerPanel"> style:"neutral|soft|solid|passive" padding:"24px" gap:"16px"
--<Row-ComposerHead "composerHead"> width:"100%" justify-content:"space-between" align-items:"flex-start" gap:"16px"
---<Col-ComposerTitleBlock "composerTitleBlock"> gap:"6px" flex:"1"
----<Text-ComposerTitle "composerTitle"> value:"快速加一条采购项" style:"contrast" font-size:"26px" font-weight:"700"
----<Text-ComposerCopy "composerCopy"> value:"填写名称、分类、数量和单价，新增后立即参与合计与筛选。" style:"body" sk.fg:"#64748B"
---<Button-CreateItem "createItemButton"> value:"添加到清单" style:"primary|filled|default|md|actionable" disabled:(!$canCreate)
--<Row-InputRow "inputRow"> width:"100%" gap:"12px"
---<Input-NameInput "nameInput"> style:"neutral|outlined|default|md" value:$draftName placeholder:"例如 三文鱼" flex:"1" min-width:"220px"
---<Input-CategoryInput "categoryInput"> style:"neutral|outlined|default|md" value:$draftCategory placeholder:"例如 生鲜" width:"180px"
---<Input-QuantityInput "quantityInput"> style:"neutral|outlined|default|md" value:$draftQuantity placeholder:"数量" width:"140px"
---<Input-PriceInput "priceInput"> style:"neutral|outlined|default|md" value:$draftUnitPrice placeholder:"单价" width:"160px"
--<Textarea-NoteInput "noteInput"> style:"neutral|outlined|soft|md" value:$draftNote placeholder:"可选备注，例如品牌、规格或优惠提醒。" min-height:"110px" width:"100%"
--<If-HasError> conditions:($errorMessage.trim().length > 0)
---<Text-ErrorMessage "errorMessage"> value:$errorMessage style:"body" padding:"10px 12px" font-weight:"600" sk.bg:"#FEF2F2" sk.fg:"#B91C1C" sk.borderColor:"#FECACA" sk.borderWidth:"1px"
-<Col-FilterPanel "filterPanel"> style:"neutral|soft|solid|passive" padding:"24px" gap:"16px"
--<Row-FilterHead "filterHead"> width:"100%" justify-content:"space-between" align-items:"flex-start" gap:"12px"
---<Col-FilterTitleBlock "filterTitleBlock"> gap:"6px" flex:"1"
----<Text-FilterTitle "filterTitle"> value:"分类与状态筛选" style:"contrast" font-size:"24px" font-weight:"700"
----<Text-FilterHint "filterHint"> value:$listHint style:"body" sk.fg:"#64748B"
---<Button-ResetFilter "resetFilterButton"> value:"重置筛选" style:"neutral|outlined|default|sm|actionable"
--<Row-StatusRow "statusRow"> gap:"12px"
---<Button-AllStatus "allStatusButton"> value:"全部" style:"neutral|ghost|pill|sm|actionable" sk.bg:($statusFilter == "all" ? "#DBEAFE" : null) sk.fg:($statusFilter == "all" ? "#2563EB" : null)
---<Button-PendingStatus "pendingStatusButton"> value:"未买" style:"neutral|ghost|pill|sm|actionable" sk.bg:($statusFilter == "pending" ? "#FEF3C7" : null) sk.fg:($statusFilter == "pending" ? "#B45309" : null)
---<Button-BoughtStatus "boughtStatusButton"> value:"已买" style:"neutral|ghost|pill|sm|actionable" sk.bg:($statusFilter == "bought" ? "#ECFDF5" : null) sk.fg:($statusFilter == "bought" ? "#047857" : null)
--<Row-CategoryRow "categoryRow"> gap:"12px"
---<Button-AllCategory "allCategoryButton"> value:"全部分类" style:"neutral|ghost|pill|sm|actionable" sk.bg:($categoryFilter == "all" ? "#E2E8F0" : null) sk.fg:($categoryFilter == "all" ? "#0F172A" : null)
---<For-CategoryTabs> sourceArray:$categoryTabs loopVar:[_item0,_index0]
----<Component-ShoppingCategoryPill "categoryPill"> width:"180px" category:_item0 selected:(_item0.name == $categoryFilter)
-<Col-ListPanel "listPanel"> style:"neutral|soft|solid|passive" padding:"24px" gap:"18px"
--<Row-ListHead "listHead"> width:"100%" justify-content:"space-between" align-items:"flex-start" gap:"12px"
---<Col-ListHeadCopy "listHeadCopy"> gap:"6px" flex:"1"
----<Text-ListTitle "listTitle"> value:"采购清单" style:"contrast" font-size:"26px" font-weight:"700"
----<Text-ListHint "listHintText"> value:(("当前展示 " + $itemList.length) + " 条商品") style:"body" sk.fg:"#64748B"
---<Row-ViewBudget "viewBudget"> style:"primary|tonal|pill|passive" padding:"10px 14px" gap:"8px" align-items:"center"
----<Text-ViewBudgetLabel "viewBudgetLabel"> value:"当前视图" style:"body" sk.fg:"#1D4ED8"
----<Text-ViewBudgetValue "viewBudgetValue"> value:$currentViewTotalLabel style:"contrast" font-size:"22px" font-weight:"700"
--<If-LoadingState> conditions:$isLoading
---<Row-LoadingState "loadingState"> style:"info|tonal|soft|passive" padding:"18px" align-items:"center" justify-content:"center"
----<Text-LoadingText "loadingText"> value:"正在同步购物清单..." style:"contrast" font-weight:"600"
--<If-HasItems> conditions:($hasItems && !$isLoading)
---<Col-ItemList "itemList"> gap:"14px"
----<For-ItemCards> sourceArray:$itemList loopVar:[_item0,_index0]
-----<Component-ShoppingItemCard "itemCard"> item:_item0
--<If-EmptyState> conditions:(!$hasItems && !$isLoading)
---<Component-ShoppingEmptyState "emptyState"> title:"当前筛选下没有商品" description:"试试重置筛选，或者先新增一条商品到购物清单。"

# Frontend Event Handlers
<Input-NameInput "nameInput">.@input(newValue, delta)
-$draftName = newValue

<Input-CategoryInput "categoryInput">.@input(newValue, delta)
-$draftCategory = newValue

<Input-QuantityInput "quantityInput">.@input(newValue, delta)
-$draftQuantity = newValue

<Input-PriceInput "priceInput">.@input(newValue, delta)
-$draftUnitPrice = newValue

<Textarea-NoteInput "noteInput">.@input(newValue, delta)
-$draftNote = newValue

<Button-CreateItem "createItemButton">.@click()
-createItem() -> _createResult

<Button-AllStatus "allStatusButton">.@click()
-$statusFilter = "all"
-loadBoard() -> _allStatusResult

<Button-PendingStatus "pendingStatusButton">.@click()
-$statusFilter = "pending"
-loadBoard() -> _pendingStatusResult

<Button-BoughtStatus "boughtStatusButton">.@click()
-$statusFilter = "bought"
-loadBoard() -> _boughtStatusResult

<Button-AllCategory "allCategoryButton">.@click()
-$categoryFilter = "all"
-loadBoard() -> _allCategoryResult

<Component-ShoppingCategoryPill "categoryPill">.@select(categoryName)
-$categoryFilter = categoryName
-loadBoard() -> _categoryResult

<Button-ResetFilter "resetFilterButton">.@click()
-$categoryFilter = "all"
-$statusFilter = "all"
-loadBoard() -> _resetFilterResult

<Component-ShoppingItemCard "itemCard">.@toggleBought(itemId, nextBought)
-<ServiceDomain-ShoppingList "shoppingService">.ToggleBought(itemId, nextBought) -> _toggleResult
-IF !_toggleResult.success
--$errorMessage = _toggleResult.message
-ELSE
--$errorMessage = ""
--loadBoard() -> _reloadAfterToggle

<Component-ShoppingItemCard "itemCard">.@quantityStep(itemId, delta)
-<ServiceDomain-ShoppingList "shoppingService">.AdjustQuantity(itemId, delta) -> _stepResult
-IF !_stepResult.success
--$errorMessage = _stepResult.message
-ELSE
--$errorMessage = ""
--loadBoard() -> _reloadAfterStep

<Component-ShoppingItemCard "itemCard">.@delete(itemId)
-<ServiceDomain-ShoppingList "shoppingService">.DeleteItem(itemId) -> _deleteResult
-IF !_deleteResult.success
--$errorMessage = _deleteResult.message
-ELSE
--$errorMessage = ""
--loadBoard() -> _reloadAfterDelete

# Frontend Internal Methods
METHOD loadBoard();RETURN {success:BOOL}
-$isLoading = true
-<ServiceDomain-ShoppingList "shoppingService">.GetBoard($categoryFilter, $statusFilter) -> _result
-$isLoading = false
-IF !_result.success
--$itemList = []
--$categoryTabs = []
--$summary = {totalItems:0,pendingItems:0,boughtItems:0,estimatedTotal:0,pendingTotal:0}
--$errorMessage = _result.message
--RETURN {success:false}
-$itemList = _result.data
-$categoryTabs = _result.categories
-$summary = _result.summary
-$errorMessage = ""
-RETURN {success:true}

METHOD createItem();RETURN {success:BOOL}
-_name(STRING) = $draftName.trim()
-_quantityValue(FLOAT) = Number($draftQuantity.trim())
-_unitPriceValue(FLOAT) = Number($draftUnitPrice.trim())
-IF _name == ""
--$errorMessage = "商品名称不能为空"
--RETURN {success:false}
-IF isNaN(_quantityValue) || _quantityValue < 1 || _quantityValue != Math.floor(_quantityValue)
--$errorMessage = "数量必须是大于等于 1 的整数"
--RETURN {success:false}
-IF isNaN(_unitPriceValue) || _unitPriceValue < 0
--$errorMessage = "单价必须是大于等于 0 的数字"
--RETURN {success:false}
-<ServiceDomain-ShoppingList "shoppingService">.CreateItem(_name, $draftCategory, parseInt($draftQuantity.trim()), _unitPriceValue, $draftNote) -> _result
-IF !_result.success
--$errorMessage = _result.message
--RETURN {success:false}
-$draftName = ""
-$draftQuantity = "1"
-$draftUnitPrice = "0"
-$draftNote = ""
-$errorMessage = ""
-loadBoard() -> _reloadAfterCreate
-RETURN {success:_reloadAfterCreate.success}

# Frontend Pipeline Funcs
</Section-ShoppingBoard>
