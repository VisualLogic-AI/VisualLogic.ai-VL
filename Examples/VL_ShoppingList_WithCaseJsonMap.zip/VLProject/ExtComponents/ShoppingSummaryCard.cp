// VL_VERSION:4.1
// Preview: width:240px height:132px
<Component-ShoppingSummaryCard "root"> padding:"0"

# Frontend Public Props
$label(STRING) = ""
$value(STRING) = "0"
$helper(STRING) = ""
$accentColor(STRING) = "#2563EB"

# Frontend Public Events

# Frontend Derived Vars

# Frontend Tree
<Col-StatCard "statCard"> style:"neutral|soft|elevated|passive" sk.borderTop:("4px solid " + $accentColor) padding:"18px" gap:"10px" min-height:"132px"
-<Text-StatLabel "statLabel"> value:$label style:"caption"
-<Text-StatValue "statValue"> value:$value style:"contrast" font-size:"30px" font-weight:"700" line-height:"1.1"
-<Text-StatHelper "statHelper"> value:$helper style:"body" line-height:"1.6" sk.fg:"#64748B"

# Frontend Event Handlers

# Frontend Internal Methods
# Frontend Pipeline Funcs
</Component-ShoppingSummaryCard>
