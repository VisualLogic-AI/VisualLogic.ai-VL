// VL_VERSION:4.1
// Preview: width:180px height:44px
<Component-ShoppingCategoryPill "root"> padding:"0"

# Frontend Public Props
$category({name:STRING,count:INT,boughtCount:INT}) = {name:"",count:0,boughtCount:0}
$selected(BOOL) = false

# Frontend Public Events
EVENT @select(categoryName(STRING))

# Frontend Derived Vars
$countLabel(STRING) = (("" + $category.count) + " 项")
$boughtLabel(STRING) = (("已买 " + $category.boughtCount) + " 项")

# Frontend Tree
<Row-PillShell "pillShell"> style:"neutral|ghost|pill|selectable" padding:"8px 12px" gap:"10px" align-items:"center" justify-content:"space-between" sk.bg:($selected ? "#DBEAFE" : "#FFFFFF") sk.fg:($selected ? "#1D4ED8" : "#0F172A") sk.borderColor:($selected ? "#93C5FD" : "#E2E8F0") sk.borderWidth:"1px"
-<Col-Copy "copy"> gap:"2px"
--<Text-Name "name"> value:$category.name style:"body" font-weight:"600" sk.fg:($selected ? "#1D4ED8" : "#0F172A")
--<Text-Helper "helper"> value:$boughtLabel style:"body" font-size:"11px" sk.fg:($selected ? "#2563EB" : "#64748B")
-<Text-Count "count"> value:$countLabel style:"body" font-weight:"600" sk.fg:($selected ? "#1D4ED8" : "#334155")

# Frontend Event Handlers
<Row-PillShell "pillShell">.@click()
-@select($category.name)

# Frontend Internal Methods
# Frontend Pipeline Funcs
</Component-ShoppingCategoryPill>
