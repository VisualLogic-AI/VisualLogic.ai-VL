// VL_VERSION:4.1
// Preview: width:100% height:280px
<Component-ShoppingEmptyState "root"> padding:"0"

# Frontend Public Props
$title(STRING) = "Nothing here yet"
$description(STRING) = "Add an item to get started."

# Frontend Public Events

# Frontend Derived Vars

# Frontend Tree
<Col-EmptyShell "emptyShell"> style:"neutral|soft|subtle|passive" padding:"36px" gap:"14px" align-items:"center" justify-content:"center" min-height:"280px"
-<Row-EmptyOrb "emptyOrb"> style:"warning|tonal|pill|passive" width:"64px" height:"64px" align-items:"center" justify-content:"center"
--<Text-EmptyMark "emptyMark"> value:"+" style:"contrast" font-size:"28px" font-weight:"700"
-<Text-EmptyTitle "emptyTitle"> value:$title style:"contrast" font-size:"24px" font-weight:"700" text-align:"center"
-<Text-EmptyDescription "emptyDescription"> value:$description style:"body" text-align:"center" width:"420px" line-height:"1.7" sk.fg:"#64748B"

# Frontend Event Handlers

# Frontend Internal Methods
# Frontend Pipeline Funcs
</Component-ShoppingEmptyState>
