// VL_VERSION:4.1
// Preview: width:320px min-height:760px
<Component-ShoppingHeroPanel "root"> style:"inverse|soft|subtle|passive" padding:"32px" gap:"22px" min-height:"calc(100vh - 64px)"

# Frontend Public Props

# Frontend Public Events

# Frontend Derived Vars
$featureList([{title:STRING,desc:STRING}]) = [{title:"列表增删",desc:"快速添加商品，也能一键删除不再需要的条目。"},{title:"数量步进",desc:"每张卡片都带加减按钮，方便验证数量变化与金额联动。"},{title:"分类筛选",desc:"支持按分类与已买状态组合筛选当前视图。"},{title:"金额合计",desc:"顶部统计卡和列表头部都会实时反映金额汇总。"}]

# Frontend Tree
<Col-HeroStack "heroStack"> gap:"22px"
-<Text-Eyebrow "eyebrow"> value:"VL SHOPPING DEMO" style:"caption"
-<Text-Headline "headline"> value:"把购物清单做成一块能立刻行动的采购板。" style:"contrast" font-size:"34px" font-weight:"700" line-height:"1.15"
-<Text-Body "body"> value:"这套示例聚焦表单录入、列表状态与金额统计，适合用来验证购物清单场景里的 VL 交互闭环。" style:"body" line-height:"1.7" sk.fg:"rgba(255,255,255,0.76)"
-<Divider-HeroDivider "heroDivider"> style:"dark"
-<Col-FeatureList "featureList"> gap:"14px"
--<For-FeatureItems> sourceArray:$featureList loopVar:[_item0,_index0]
---<Row-FeatureItem "featureItem"> gap:"12px" align-items:"flex-start"
----<Row-IndexBadge "indexBadge"> style:"primary|filled|pill|passive" width:"30px" height:"30px" align-items:"center" justify-content:"center"
-----<Text-IndexLabel "indexLabel"> value:("" + (_index0 + 1)) style:"contrast" text-align:"center" font-weight:"700"
----<Col-FeatureCopy "featureCopy"> gap:"4px"
-----<Text-FeatureTitle "featureTitle"> value:_item0.title style:"contrast" font-weight:"600"
-----<Text-FeatureHint "featureHint"> value:_item0.desc style:"body" line-height:"1.6" sk.fg:"rgba(255,255,255,0.72)"
-<Col-TestingPanel "testingPanel"> style:"neutral|soft|solid|passive" padding:"16px" gap:"8px" margin-top:"auto"
--<Text-TestingTitle "testingTitle"> value:"建议测试顺序" style:"contrast" font-weight:"700"
--<Text-TestingBody "testingBody"> value:"先新增商品，再对同一项连续点数量加减和已买切换，最后观察筛选和合计是否同步变化。" style:"body" line-height:"1.7" sk.fg:"#CBD5E1"

# Frontend Event Handlers

# Frontend Internal Methods
# Frontend Pipeline Funcs
</Component-ShoppingHeroPanel>
