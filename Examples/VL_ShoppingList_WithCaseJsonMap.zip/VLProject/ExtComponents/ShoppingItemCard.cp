// VL_VERSION:4.1
// Preview: width:100% min-height:220px
<Component-ShoppingItemCard "root"> padding:"0"

# Frontend Public Props
$item({_id:INT,name:STRING,category:STRING,quantity:INT,unitPrice:FLOAT,isBought:BOOL,note:STRING,subtotal:FLOAT}) = {_id:0,name:"",category:"",quantity:1,unitPrice:0,isBought:false,note:"",subtotal:0}

# Frontend Public Events
EVENT @toggleBought(itemId(INT),nextBought(BOOL))
EVENT @quantityStep(itemId(INT),delta(INT))
EVENT @delete(itemId(INT))

# Frontend Derived Vars
$categoryColor(STRING) = ($item.category == "蔬果" ? "#10B981" : ($item.category == "乳制品" ? "#3B82F6" : ($item.category == "生鲜" ? "#EF4444" : ($item.category == "家居" ? "#8B5CF6" : "#F59E0B"))))
$statusLabel(STRING) = ($item.isBought ? "已买" : "未买")
$subtotalLabel(STRING) = ("¥" + $item.subtotal.toFixed(2))
$unitPriceLabel(STRING) = ("单价 ¥" + $item.unitPrice.toFixed(2))
$quantityLabel(STRING) = ("数量 " + $item.quantity)
$toggleLabel(STRING) = ($item.isBought ? "改回未买" : "标记已买")

# Frontend Tree
<Col-CardShell "cardShell"> style:"neutral|soft|solid|passive" sk.borderLeft:("4px solid " + ($item.isBought ? "#10B981" : $categoryColor)) padding:"20px" gap:"16px"
-<Row-TopRow "topRow"> width:"100%" justify-content:"space-between" align-items:"flex-start" gap:"14px"
--<Col-TitleBlock "titleBlock"> gap:"8px" flex:"1"
---<Text-Title "title"> value:$item.name style:"contrast" font-size:"24px" font-weight:"700" text-decoration:($item.isBought ? "line-through" : "none")
---<If-HasNote> conditions:($item.note.trim().length > 0)
----<Text-Note "note"> value:$item.note style:"body" line-height:"1.7" sk.fg:"#64748B"
--<Row-CategoryBadge "categoryBadge"> style:"neutral|tonal|pill|passive" padding:"6px 12px" align-items:"center" justify-content:"center" sk.bg:$categoryColor
---<Text-CategoryText "categoryText"> value:$item.category style:"contrast" font-size:"12px" font-weight:"700"
-<Row-MetaRow "metaRow"> gap:"10px"
--<Text-StatusTag "statusTag"> value:$statusLabel style:"body" padding:"6px 10px" font-weight:"600" sk.bg:($item.isBought ? "#ECFDF5" : "#FEF3C7") sk.fg:($item.isBought ? "#047857" : "#B45309") sk.borderColor:($item.isBought ? "#A7F3D0" : "#FDE68A") sk.borderWidth:"1px"
--<Text-PriceTag "priceTag"> value:$unitPriceLabel style:"body" padding:"6px 10px" sk.bg:"#EFF6FF" sk.fg:"#1D4ED8" sk.borderColor:"#BFDBFE" sk.borderWidth:"1px"
--<Text-SubtotalTag "subtotalTag"> value:("小计 " + $subtotalLabel) style:"body" padding:"6px 10px" sk.bg:"#F8FAFC" sk.fg:"#0F172A" sk.borderColor:"#E2E8F0" sk.borderWidth:"1px"
-<Row-BottomRow "bottomRow"> justify-content:"space-between" align-items:"center" gap:"12px"
--<Row-Stepper "stepper"> gap:"10px" align-items:"center"
---<Button-StepDown "stepDownButton"> value:"-" style:"neutral|outlined|default|sm|actionable" disabled:($item.quantity <= 1)
---<Text-QuantityText "quantityText"> value:$quantityLabel style:"contrast" font-weight:"700"
---<Button-StepUp "stepUpButton"> value:"+" style:"neutral|outlined|default|sm|actionable"
--<Row-ActionButtons "actionButtons"> gap:"10px"
---<Button-ToggleBought "toggleBoughtButton"> value:$toggleLabel style:"success|filled|default|sm|actionable" sk.bg:($item.isBought ? "#E2E8F0" : null) sk.fg:($item.isBought ? "#0F172A" : null)
---<Button-DeleteItem "deleteItemButton"> value:"删除" style:"danger|ghost|default|sm|actionable"

# Frontend Event Handlers
<Button-StepDown "stepDownButton">.@click()
-@quantityStep($item._id, -1)

<Button-StepUp "stepUpButton">.@click()
-@quantityStep($item._id, 1)

<Button-ToggleBought "toggleBoughtButton">.@click()
-@toggleBought($item._id, !$item.isBought)

<Button-DeleteItem "deleteItemButton">.@click()
-@delete($item._id)

# Frontend Internal Methods
# Frontend Pipeline Funcs
</Component-ShoppingItemCard>
