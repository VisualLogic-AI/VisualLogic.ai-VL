// VL_VERSION:4.1
<ServiceDomain-ShoppingList>

# Backend Tree
<ServiceDomainRoot-Root>
-<VirtualTable-Items "itemTable"> sourceTable:Items
--<Field-name> type:STRING
--<Field-category> type:STRING
--<Field-quantity> type:INT
--<Field-unitPrice> type:FLOAT
--<Field-isBought> type:BOOL
--<Field-note> type:STRING

# Services
SERVICE GetBoard(categoryFilter(STRING),statusFilter(STRING));RETURN {success:BOOL,data:[{}],summary:{},categories:[{}],message:STRING}
-_conditions([[]]) = []
-IF categoryFilter.trim() != "" && categoryFilter != "all"
--_conditions.push(["category","eq",categoryFilter.trim()])
-IF statusFilter == "pending"
--_conditions.push(["isBought","eq",false])
-ELSE IF statusFilter == "bought"
--_conditions.push(["isBought","eq",true])
-<VirtualTable-Items "itemTable">.select((_conditions.length > 0 ? _conditions : null),[["isBought","asc"],["category","asc"],["_update","desc"]],[0,300]) -> _filteredResult
-<VirtualTable-Items "itemTable">.select(null,[["isBought","asc"],["category","asc"],["_update","desc"]],[0,300]) -> _allResult
-buildViewItems(_filteredResult.dataArray) -> _viewResult
-buildSummary(_allResult.dataArray) -> _summaryResult
-buildCategories(_allResult.dataArray) -> _categoriesResult
-RETURN {success:true,data:_viewResult.data,summary:_summaryResult.summary,categories:_categoriesResult.categories,message:""}

SERVICE CreateItem(name(STRING),category(STRING),quantity(INT),unitPrice(FLOAT),note(STRING));RETURN {success:BOOL,message:STRING,dataId:INT}
-_name(STRING) = name.trim()
-normalizeCategory(category) -> _categoryResult
-_quantity(INT) = (quantity >= 1 ? quantity : 1)
-_unitPrice(FLOAT) = (unitPrice >= 0 ? unitPrice : 0)
-IF _name == ""
--RETURN {success:false,message:"商品名称不能为空",dataId:0}
-<VirtualTable-Items "itemTable">.insert({name:_name,category:_categoryResult.category,quantity:_quantity,unitPrice:_unitPrice,isBought:false,note:note.trim()}) -> _insertResult
-IF !_insertResult.success
--RETURN {success:false,message:_insertResult.message,dataId:0}
-RETURN {success:true,message:"商品已加入清单",dataId:_insertResult.dataId}

SERVICE ToggleBought(itemId(INT),nextBought(BOOL));RETURN {success:BOOL,message:STRING}
-<VirtualTable-Items "itemTable">.update([["_id","eq",itemId]],[["isBought","set",nextBought]],1) -> _updateResult
-IF !_updateResult.success || _updateResult.affect == 0
--RETURN {success:false,message:"商品状态更新失败"}
-RETURN {success:true,message:(nextBought ? "已标记为已买" : "已改回未买")}

SERVICE AdjustQuantity(itemId(INT),delta(INT));RETURN {success:BOOL,message:STRING}
-<VirtualTable-Items "itemTable">.select([["_id","eq",itemId]],[["_update","desc"]],[0,1]) -> _selectResult
-IF _selectResult.dataArray.length == 0
--RETURN {success:false,message:"未找到对应商品"}
-_item({}) = _selectResult.dataArray[0]
-_nextQuantity(INT) = (_item.quantity + delta)
-IF _nextQuantity < 1
--_nextQuantity = 1
-<VirtualTable-Items "itemTable">.update([["_id","eq",itemId]],[["quantity","set",_nextQuantity]],1) -> _updateResult
-IF !_updateResult.success || _updateResult.affect == 0
--RETURN {success:false,message:"数量更新失败"}
-RETURN {success:true,message:"数量已更新"}

SERVICE DeleteItem(itemId(INT));RETURN {success:BOOL,message:STRING}
-<VirtualTable-Items "itemTable">.delete([["_id","eq",itemId]],1) -> _deleteResult
-IF !_deleteResult.success || _deleteResult.affect == 0
--RETURN {success:false,message:"删除商品失败"}
-RETURN {success:true,message:"商品已删除"}

# Backend Event Handlers

# Transactions

# Backend Internal Methods
METHOD normalizeCategory(category(STRING));RETURN {category:STRING}
-_category(STRING) = (category && category.trim().length > 0 ? category.trim() : "杂货")
-RETURN {category:_category}

METHOD buildViewItems(items([{}]));RETURN {data:[{}]}
-_data([{}]) = []
-FOR (_item0, _index0) IN items
--_subtotal(FLOAT) = (_item0.quantity * _item0.unitPrice)
--_data.push({_id:_item0._id,name:_item0.name,category:_item0.category,quantity:_item0.quantity,unitPrice:_item0.unitPrice,isBought:_item0.isBought,note:_item0.note,subtotal:_subtotal})
-RETURN {data:_data}

METHOD buildSummary(items([{}]));RETURN {summary:{}}
-_pendingItems(INT) = 0
-_estimatedTotal(FLOAT) = 0
-_pendingTotal(FLOAT) = 0
-FOR (_item0, _index0) IN items
--_subtotal(FLOAT) = (_item0.quantity * _item0.unitPrice)
--_estimatedTotal = _estimatedTotal + _subtotal
--IF !_item0.isBought
---_pendingItems = _pendingItems + 1
---_pendingTotal = _pendingTotal + _subtotal
-_totalItems(INT) = items.length
-_boughtItems(INT) = (_totalItems - _pendingItems)
-RETURN {summary:{totalItems:_totalItems,pendingItems:_pendingItems,boughtItems:_boughtItems,estimatedTotal:_estimatedTotal,pendingTotal:_pendingTotal}}

METHOD buildCategories(items([{}]));RETURN {categories:[{}]}
-_categoryMap({}) = {}
-_categoryNames([STRING]) = []
-FOR (_item0, _index0) IN items
--normalizeCategory(_item0.category) -> _categoryResult
--_categoryName(STRING) = _categoryResult.category
--IF !_categoryMap[_categoryName]
---_categoryMap[_categoryName] = {name:_categoryName,count:0,boughtCount:0}
---_categoryNames.push(_categoryName)
--_categoryMap[_categoryName].count = _categoryMap[_categoryName].count + 1
--IF _item0.isBought
---_categoryMap[_categoryName].boughtCount = _categoryMap[_categoryName].boughtCount + 1
-_categoryNames.sort()
-_categories([{}]) = []
-FOR (_name0, _index1) IN _categoryNames
--_categories.push(_categoryMap[_name0])
-RETURN {categories:_categories}

# Backend Pipeline Funcs
</ServiceDomain-ShoppingList>
