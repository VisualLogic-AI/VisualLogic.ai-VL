# CourseScheduler

这个 Workspace 用于验证以下能力：

- 网格布局课程表
- 时间段展示
- 颜色标签
- 冲突提示
- 编辑弹窗
- 保存后局部刷新
