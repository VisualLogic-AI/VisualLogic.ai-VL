// VL_VERSION:4.1
// Preview: width:100% min-height:980px
<Section-ScheduleBoard "root"> containerType:col gap:"20px"

# Frontend Global Vars
$scheduleEntries([{}]) = []
$conflictIds([INT]) = []
$conflictPairs([{}]) = []
$conflictSummary(STRING) = ""
$selectedEntryId(INT) = 0
$isEditorVisible(BOOL) = false
$isCreateMode(BOOL) = true
$isSaving(BOOL) = false
$editorMessage(STRING) = ""
$entryForm({title:STRING,dayOfWeek:INT,startSlot:INT,endSlot:INT,teacher:STRING,location:STRING,tagColor:STRING,notes:STRING}) = {title:"",dayOfWeek:1,startSlot:1,endSlot:1,teacher:"",location:"",tagColor:"#2563EB",notes:""}
$weekdayList([{}]) = [{value:1,label:"Monday",short:"Mon"},{value:2,label:"Tuesday",short:"Tue"},{value:3,label:"Wednesday",short:"Wed"},{value:4,label:"Thursday",short:"Thu"},{value:5,label:"Friday",short:"Fri"}]
$slotList([{}]) = [{value:1,label:"08:00 - 08:45"},{value:2,label:"09:00 - 09:45"},{value:3,label:"10:00 - 10:45"},{value:4,label:"11:00 - 11:45"},{value:5,label:"13:00 - 13:45"},{value:6,label:"14:00 - 14:45"},{value:7,label:"15:00 - 15:45"},{value:8,label:"16:00 - 16:45"}]
$gridCells([{}]) = []

# Frontend Derived Vars
$hasConflicts(BOOL) = ($conflictIds.length > 0)
$boardHint(STRING) = ($hasConflicts ? "Highlighted cards overlap on the same weekday." : "All visible classes are currently conflict-free.")

# Frontend Tree
<ServiceDomain-ScheduleService "scheduleService">
-<Service-ListSchedule> returns:(success(BOOL),data([{}]),conflicts([{}]))
-<Service-SaveScheduleEntry> params:(entryId(INT),title(STRING),dayOfWeek(INT),startSlot(INT),endSlot(INT),teacher(STRING),location(STRING),tagColor(STRING),notes(STRING)) returns:(success(BOOL),message(STRING),hasConflict(BOOL),conflicts([{}]))
-<Service-DeleteScheduleEntry> params:(entryId(INT)) returns:(success(BOOL),message(STRING))

<Col-Hero "heroPanel"> padding:"24px" gap:"10px" style:"solid|soft|passive"
-<Text-PageTitle "pageTitle"> value:"CourseScheduler" style:"contrast" font-size:"32px" font-weight:"700"
-<Text-PageSubtitle "pageSubtitle"> value:"课程表 / 日程表测试项目，覆盖网格布局、时间段展示、颜色标签、冲突提示与编辑弹窗。" style:"muted" font-size:"14px"

<Row-Toolbar "toolbar"> align-items:"center" justify-content:"space-between" gap:"16px" style:"solid|soft|passive" padding:"16px 18px"
-<Col-ToolbarInfo "toolbarInfo"> gap:"4px"
--<Text-ToolbarTitle "toolbarTitle"> value:"Weekly Schedule" font-size:"18px" font-weight:"700"
--<Text-ToolbarHint "toolbarHint"> value:$boardHint style:"caption" font-size:"12px"
-<Row-ToolbarActions "toolbarActions"> align-items:"center" gap:"12px"
--<Component-ConflictBadge "conflictBadge"> width:"280px" count:$conflictIds.length message:($hasConflicts ? $conflictSummary : "No overlaps detected")
--<Button-CreateEntry "createEntryButton"> value:"新增课程" style:"primary|filled|default|md|actionable"

<Row-BoardFrame "boardFrame"> width:100% gap:"16px" align-items:"stretch"
-<Col-TimeAxis "timeAxis"> width:"150px" gap:"8px"
--<Row-TimeAxisHeader "timeAxisHeader"> height:"56px" align-items:"center" padding:"0 8px"
---<Text-TimeAxisTitle "timeAxisTitle"> value:"Time" style:"caption" font-size:"12px"
--<For-TimeSlots> sourceArray:$slotList loopVar:[_slot0,_slotIndex0]
---<Col-TimeAxisCell "timeAxisCell"> height:"92px" justify-content:"center" gap:"4px" padding:"10px 8px" style:"subtle|square|passive"
----<Text-TimeAxisSlot "timeAxisSlot"> value:("Slot " + _slot0.value) font-size:"13px" font-weight:"600"
----<Text-TimeAxisRange "timeAxisRange"> value:_slot0.label style:"caption" font-size:"12px"
-<Col-BoardMain "boardMain"> flex:"1" gap:"8px"
--<Grid-WeekdayHeader "weekdayHeader"> grid-template-columns:"repeat(5, minmax(0, 1fr))" gap:"8px"
---<For-Weekdays> sourceArray:$weekdayList loopVar:[_day0,_dayIndex0]
----<Col-WeekdayCell "weekdayCell"> padding:"14px 12px" gap:"4px" style:"solid|soft|passive"
-----<Text-WeekdayShort "weekdayShort"> value:_day0.short font-size:"13px" font-weight:"700"
-----<Text-WeekdayLabel "weekdayLabel"> value:_day0.label style:"caption" font-size:"12px"
--<Grid-ScheduleGrid "scheduleGrid"> grid-template-columns:"repeat(5, minmax(0, 1fr))" grid-template-rows:"repeat(8, 92px)" gap:"8px" min-height:"736px"
---<For-GridCells> sourceArray:$gridCells loopVar:[_cell0,_cellIndex0]
----<Col-GridCell "gridCell"> grid-column:("" + _cell0.dayOfWeek) grid-row:("" + _cell0.slot) padding:"6px" style:"subtle|square|passive"
---<For-ScheduleEntries> sourceArray:$scheduleEntries loopVar:[_entry0,_entryIndex0]
----<Col-ScheduleEventCell "scheduleEventCell"> height:"100%" grid-column:("" + _entry0.dayOfWeek) grid-row:("" + _entry0.startSlot + " / " + (_entry0.endSlot + 1)) padding:"4px"
-----<Component-ScheduleEventCard "scheduleEventCard"> flex:"1" item:_entry0 selected:($selectedEntryId == _entry0._id) isConflict:$conflictIds.includes(_entry0._id)

<If-ShowConflictPanel> conditions:$hasConflicts
-<Col-ConflictPanel "conflictPanel"> padding:"16px" gap:"10px" style:"danger|outlined|default|passive" sk.bg:"#FEF2F2"
--<Text-ConflictPanelTitle "conflictPanelTitle"> value:"Conflict Summary" style:"danger|caption" font-size:"12px"
--<Text-ConflictPanelBody "conflictPanelBody"> value:$conflictSummary font-size:"13px"
--<For-ConflictEntries> sourceArray:$conflictPairs loopVar:[_conflict0,_conflictIndex0]
---<Row-ConflictRow "conflictRow"> gap:"10px" align-items:"center" padding:"10px" style:"solid|default|passive" sk.borderLeft:("4px solid " + _conflict0.tagColor)
----<Row-ConflictDot "conflictDot"> width:"10px" height:"10px" style:"pill|passive" sk.bg:_conflict0.tagColor
----<Text-ConflictRowText "conflictRowText"> value:(_conflict0.entryTitle + " ↔ " + _conflict0.conflictWithTitle + " | " + _conflict0.dayLabel + " | " + _conflict0.slotLabel + " | " + _conflict0.locationLabel) font-size:"13px"

<Modal-EntryEditor "entryEditorModal"> show:$isEditorVisible width:"640px" height:"760px" mask:true maskColor:"rgba(15,23,42,0.45)" placement:"middleCenter" style:"overlay|soft"
-<Col-EntryEditorBody "entryEditorBody"> height:100% padding:"20px" gap:"16px" overflow:"auto"
--<Row-EntryEditorHead "entryEditorHead"> justify-content:"space-between" align-items:"center" gap:"12px"
---<Col-EntryEditorTitleWrap "entryEditorTitleWrap"> gap:"6px"
----<Text-EntryEditorTitle "entryEditorTitle"> value:($isCreateMode ? "新增课程" : "编辑课程") font-size:"22px" font-weight:"700"
----<Text-EntryEditorHint "entryEditorHint"> value:"保存后会立即重新拉取课程表并更新冲突提示。" style:"caption" font-size:"12px"
---<Button-CloseEditor "closeEditorButton"> value:"关闭" style:"neutral|ghost|default|sm|actionable" disabled:$isSaving
--<If-ShowEditorMessage> conditions:($editorMessage.trim() != "")
---<Col-EditorMessage "editorMessagePanel"> width:100% flex:"none" padding:"12px" gap:"6px" style:"danger|outlined|default|passive" sk.bg:"#FEF2F2"
----<Text-EditorMessageTitle "editorMessageTitle"> value:"提醒" style:"danger|caption" font-size:"12px"
----<Text-EditorMessageBody "editorMessageBody"> value:$editorMessage font-size:"13px" line-height:"1.5" white-space:"normal"
--<Component-EventEditorForm "eventEditorForm"> flex:"1" form:$entryForm isCreateMode:$isCreateMode isSaving:$isSaving

# Frontend Event Handlers
<Section-ScheduleBoard "root">.@init()
-buildGridCells() -> _gridBuilt
-loadSchedule() -> _loaded

<Button-CreateEntry "createEntryButton">.@click()
-openCreateEditor() -> _opened

<Component-ScheduleEventCard "scheduleEventCard">.@editRequested(itemId)
-openEditEditor(itemId) -> _opened

<Modal-EntryEditor "entryEditorModal">.@clickMask()
-closeEditor() -> _closed

<Button-CloseEditor "closeEditorButton">.@click()
-closeEditor() -> _closed

<Component-EventEditorForm "eventEditorForm">.@cancel()
-closeEditor() -> _closed

<Component-EventEditorForm "eventEditorForm">.@delete()
-deleteEntry() -> _deleted

<Component-EventEditorForm "eventEditorForm">.@change(formData)
-$entryForm = formData

<Component-EventEditorForm "eventEditorForm">.@submit(formData)
-saveEntry(formData) -> _saved

# Frontend Internal Methods
METHOD buildGridCells(); RETURN {success:BOOL}
-_cells([{}]) = []
-FOR (_day0, _dayIndex0) IN $weekdayList
--FOR (_slot0, _slotIndex0) IN $slotList
---_cells.push({dayOfWeek:_day0.value,slot:_slot0.value})
-$gridCells = _cells
-RETURN {success:true}

METHOD loadSchedule(); RETURN {success:BOOL}
-<ServiceDomain-ScheduleService "scheduleService">.ListSchedule() -> _result
-IF !_result.success
--<SysUI>.showToast("Failed to load schedule entries", "error")
--RETURN {success:false}
-$scheduleEntries = _result.data
-rebuildConflictState(_result.conflicts) -> _rebuilt
-RETURN {success:true}

METHOD rebuildConflictState(conflicts([{}])); RETURN {success:BOOL}
-_ids([INT]) = []
-_pairs([{}]) = []
-FOR (_conflict0, _conflictIndex0) IN conflicts
--IF !_ids.includes(_conflict0.entryId)
---_ids.push(_conflict0.entryId)
--IF !_ids.includes(_conflict0.conflictWithId)
---_ids.push(_conflict0.conflictWithId)
--_entryTitle(STRING) = ""
--_conflictWithTitle(STRING) = ""
--_entryLocation(STRING) = ""
--_conflictWithLocation(STRING) = ""
--_tagColor(STRING) = "#EF4444"
--FOR (_entry0, _entryIndex0) IN $scheduleEntries
---IF _entry0._id == _conflict0.entryId
----_entryTitle = _entry0.title
----_entryLocation = _entry0.location
----_tagColor = _entry0.tagColor
---IF _entry0._id == _conflict0.conflictWithId
----_conflictWithTitle = _entry0.title
----_conflictWithLocation = _entry0.location
--_dayLabel(STRING) = "Unknown"
--IF _conflict0.dayOfWeek == 1
---_dayLabel = "Mon"
--IF _conflict0.dayOfWeek == 2
---_dayLabel = "Tue"
--IF _conflict0.dayOfWeek == 3
---_dayLabel = "Wed"
--IF _conflict0.dayOfWeek == 4
---_dayLabel = "Thu"
--IF _conflict0.dayOfWeek == 5
---_dayLabel = "Fri"
--_locationLabel(STRING) = (_entryLocation == _conflictWithLocation ? _entryLocation : (_entryLocation + " / " + _conflictWithLocation))
--_pairs.push({entryId:_conflict0.entryId,conflictWithId:_conflict0.conflictWithId,entryTitle:_entryTitle,conflictWithTitle:_conflictWithTitle,locationLabel:_locationLabel,dayLabel:_dayLabel,slotLabel:("Slot " + _conflict0.startSlot + "-" + _conflict0.endSlot),tagColor:_tagColor})
-$conflictIds = _ids
-$conflictPairs = _pairs
-$conflictSummary = (_ids.length > 0 ? ("Detected " + _ids.length + " entries involved in overlapping time ranges.") : "No overlaps detected.")
-RETURN {success:true}

METHOD openCreateEditor(); RETURN {success:BOOL}
-$selectedEntryId = 0
-$isCreateMode = true
-$editorMessage = ""
-$entryForm = {title:"",dayOfWeek:1,startSlot:1,endSlot:1,teacher:"",location:"",tagColor:"#2563EB",notes:""}
-$isEditorVisible = true
-RETURN {success:true}

METHOD openEditEditor(itemId(INT)); RETURN {success:BOOL}
-_found(BOOL) = false
-_selected({}) = {}
-FOR (_entry0, _entryIndex0) IN $scheduleEntries
--IF _entry0._id == itemId
---_found = true
---_selected = _entry0
-IF !_found
--<SysUI>.showToast("Schedule entry not found", "error")
--RETURN {success:false}
-$selectedEntryId = itemId
-$isCreateMode = false
-$editorMessage = ($conflictIds.includes(itemId) ? "当前课程与同日其他课程存在时间冲突，请调整时间段。" : "")
-$entryForm = {title:_selected.title,dayOfWeek:_selected.dayOfWeek,startSlot:_selected.startSlot,endSlot:_selected.endSlot,teacher:_selected.teacher,location:_selected.location,tagColor:_selected.tagColor,notes:_selected.notes}
-$isEditorVisible = true
-RETURN {success:true}

METHOD closeEditor(); RETURN {success:BOOL}
-$isEditorVisible = false
-$isSaving = false
-$editorMessage = ""
-$selectedEntryId = 0
-RETURN {success:true}

METHOD saveEntry(formData({title:STRING,dayOfWeek:INT,startSlot:INT,endSlot:INT,teacher:STRING,location:STRING,tagColor:STRING,notes:STRING})); RETURN {success:BOOL}
-IF (formData.title.trim() == "" || formData.teacher.trim() == "" || formData.location.trim() == "")
--$editorMessage = "课程名称、教师和地点不能为空。"
--<SysUI>.showToast($editorMessage, "error")
--RETURN {success:false}
-IF (formData.dayOfWeek < 1 || formData.dayOfWeek > 5 || formData.startSlot < 1 || formData.startSlot > 8 || formData.endSlot < 1 || formData.endSlot > 8)
--$editorMessage = "工作日范围为 1-5，节次范围为 1-8。"
--<SysUI>.showToast($editorMessage, "error")
--RETURN {success:false}
-IF formData.endSlot < formData.startSlot
--$editorMessage = "结束节次不能早于开始节次。"
--<SysUI>.showToast($editorMessage, "error")
--RETURN {success:false}
-$isSaving = true
-<ServiceDomain-ScheduleService "scheduleService">.SaveScheduleEntry(($isCreateMode ? 0 : $selectedEntryId), formData.title, formData.dayOfWeek, formData.startSlot, formData.endSlot, formData.teacher, formData.location, formData.tagColor, formData.notes) -> _result
-$isSaving = false
-IF !_result.success
--$editorMessage = _result.message
--<SysUI>.showToast(_result.message, "error")
--RETURN {success:false}
-$editorMessage = (_result.hasConflict ? "保存成功，但当前课程仍与其他课程时间重叠，请留意下方冲突提示。" : "")
-$isEditorVisible = false
-$selectedEntryId = 0
-loadSchedule() -> _reloaded
-<SysUI>.showToast(($isCreateMode ? "课程已新增" : "课程已更新"), (_result.hasConflict ? "warning" : "success"))
-RETURN {success:true}

METHOD deleteEntry(); RETURN {success:BOOL}
-IF $selectedEntryId <= 0
--<SysUI>.showToast("当前没有可删除的课程", "error")
--RETURN {success:false}
-$isSaving = true
-<ServiceDomain-ScheduleService "scheduleService">.DeleteScheduleEntry($selectedEntryId) -> _result
-$isSaving = false
-IF !_result.success
--$editorMessage = _result.message
--<SysUI>.showToast(_result.message, "error")
--RETURN {success:false}
-$isEditorVisible = false
-$selectedEntryId = 0
-$editorMessage = ""
-loadSchedule() -> _reloaded
-<SysUI>.showToast("课程已删除", "success")
-RETURN {success:true}

# Frontend Pipeline Funcs
</Section-ScheduleBoard>
