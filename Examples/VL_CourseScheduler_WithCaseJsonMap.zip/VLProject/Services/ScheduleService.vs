// VL_VERSION:4.1
<ServiceDomain-ScheduleService>

# Backend Tree
<VirtualTable-ScheduleEntries "scheduleEntryTable"> sourceTable:ScheduleEntries
-<Field-title> type:STRING
-<Field-dayOfWeek> type:INT
-<Field-startSlot> type:INT
-<Field-endSlot> type:INT
-<Field-teacher> type:STRING
-<Field-location> type:STRING
-<Field-tagColor> type:STRING
-<Field-notes> type:STRING

# Services
SERVICE ListSchedule();RETURN {success:BOOL,data:[{}],conflicts:[{}]}
-listEntries() -> _entries
-RETURN {success:true,data:_entries.data,conflicts:_entries.conflicts}

SERVICE SaveScheduleEntry(entryId(INT),title(STRING),dayOfWeek(INT),startSlot(INT),endSlot(INT),teacher(STRING),location(STRING),tagColor(STRING),notes(STRING));RETURN {success:BOOL,message:STRING,hasConflict:BOOL,conflicts:[{}]}
-GUARD (title.trim() == "") "title is required"
-GUARD (teacher.trim() == "") "teacher is required"
-GUARD (location.trim() == "") "location is required"
-GUARD (dayOfWeek < 1 || dayOfWeek > 5) "dayOfWeek must be between 1 and 5"
-GUARD (startSlot < 1 || startSlot > 8) "startSlot must be between 1 and 8"
-GUARD (endSlot < 1 || endSlot > 8) "endSlot must be between 1 and 8"
-GUARD (endSlot < startSlot) "endSlot must be greater than or equal to startSlot"
-detectConflicts(dayOfWeek, startSlot, endSlot, entryId) -> _conflicts
-IF entryId == 0
--<VirtualTable-ScheduleEntries "scheduleEntryTable">.insert({title:title,dayOfWeek:dayOfWeek,startSlot:startSlot,endSlot:endSlot,teacher:teacher,location:location,tagColor:tagColor,notes:notes}) -> _created
--GUARD (!_created.success) _created.message
-IF entryId > 0
--<VirtualTable-ScheduleEntries "scheduleEntryTable">.update([["_id","eq",entryId]],[["title","set",title],["dayOfWeek","set",dayOfWeek],["startSlot","set",startSlot],["endSlot","set",endSlot],["teacher","set",teacher],["location","set",location],["tagColor","set",tagColor],["notes","set",notes]],1) -> _updated
--GUARD (!_updated.success) _updated.message
--GUARD (_updated.affect == 0) "Schedule entry not found"
-RETURN {success:true,message:(_conflicts.conflicts.length > 0 ? "Schedule entry saved with overlap warning" : "Schedule entry saved"),hasConflict:(_conflicts.conflicts.length > 0),conflicts:_conflicts.conflicts}

SERVICE DeleteScheduleEntry(entryId(INT));RETURN {success:BOOL,message:STRING}
-GUARD (entryId <= 0) "entryId is required"
-<VirtualTable-ScheduleEntries "scheduleEntryTable">.delete([["_id","eq",entryId]],1) -> _deleted
-GUARD (!_deleted.success) _deleted.message
-GUARD (_deleted.affect == 0) "Schedule entry not found"
-RETURN {success:true,message:"Schedule entry deleted"}

# Backend Event Handlers
# Transactions

# Backend Internal Methods
METHOD listEntries(); RETURN {data:[{}],conflicts:[{}]}
-<VirtualTable-ScheduleEntries "scheduleEntryTable">.select(null,[["dayOfWeek","asc"],["startSlot","asc"],["_id","asc"]],[0,500]) -> _entries
-GUARD (!_entries.success) _entries.message
-_conflicts([{}]) = []
-FOR (_item0, _index0) IN _entries.dataArray
--detectConflicts(_item0.dayOfWeek, _item0.startSlot, _item0.endSlot, _item0._id) -> _itemConflict
--FOR (_conflict0, _conflictIndex0) IN _itemConflict.conflicts
---_exists(BOOL) = false
---FOR (_saved0, _savedIndex0) IN _conflicts
----IF ((_saved0.entryId == _conflict0.entryId && _saved0.conflictWithId == _conflict0.conflictWithId) || (_saved0.entryId == _conflict0.conflictWithId && _saved0.conflictWithId == _conflict0.entryId))
-----_exists = true
---IF !_exists
----_conflicts.push(_conflict0)
-RETURN {data:_entries.dataArray,conflicts:_conflicts}

METHOD detectConflicts(dayOfWeek(INT), startSlot(INT), endSlot(INT), excludeId(INT)); RETURN {conflicts:[{}]}
-<VirtualTable-ScheduleEntries "scheduleEntryTable">.select([["dayOfWeek","eq",dayOfWeek]],[["startSlot","asc"],["_id","asc"]],[0,200]) -> _entries
-GUARD (!_entries.success) _entries.message
-_conflicts([{}]) = []
-FOR (_item0, _index0) IN _entries.dataArray
--IF (_item0._id != excludeId && !(endSlot < _item0.startSlot || startSlot > _item0.endSlot))
---_conflicts.push({entryId:(excludeId > 0 ? excludeId : _item0._id),conflictWithId:_item0._id,dayOfWeek:dayOfWeek,startSlot:startSlot,endSlot:endSlot})
-RETURN {conflicts:_conflicts}

# Backend Pipeline Funcs
</ServiceDomain-ScheduleService>
