// VL_VERSION:4.1
// Preview: width:100% height:140px
<Component-ScheduleEventCard "root"> containerType:col

# Frontend Public Props
$item({title:STRING,dayOfWeek:INT,startSlot:INT,endSlot:INT,teacher:STRING,location:STRING,tagColor:STRING,notes:STRING,_id:INT}) = {title:"",dayOfWeek:1,startSlot:1,endSlot:1,teacher:"",location:"",tagColor:"#2563EB",notes:"",_id:0}
$selected(BOOL) = false
$isConflict(BOOL) = false

# Frontend Public Events
EVENT @editRequested(itemId(INT))

# Frontend Derived Vars
$timeLabel(STRING) = ("Slot " + String($item.startSlot) + " - " + String($item.endSlot))
$cardBg(STRING) = ($isConflict ? "#FFF4F4" : ($selected ? "#F5F9FF" : "#FFFFFF"))

# Frontend Tree
<Col-CardShell "cardShell"> height:"100%" padding:"10px" gap:"6px" justify-content:"space-between" style:"solid|soft|selectable" sk.bg:$cardBg sk.borderColor:($isConflict ? "#EF4444" : ($selected ? "#2563EB" : "#DDE6F2")) sk.borderWidth:($isConflict ? "2px" : ($selected ? "2px" : "1px"))
-<Row-CardTop "cardTop"> width:100% justify-content:"space-between" align-items:"flex-start" gap:"8px"
--<Col-CardInfo "cardInfo"> gap:"2px" flex:"1"
---<Text-CardTitle "cardTitle"> value:$item.title style:"contrast" font-size:"14px" font-weight:"700" overflow:"hidden" text-overflow:"ellipsis" white-space:"nowrap"
---<Text-CardTeacher "cardTeacher"> value:$item.teacher style:"muted" font-size:"12px" overflow:"hidden" text-overflow:"ellipsis" white-space:"nowrap"
--<Row-ColorTag "colorTag"> min-width:"10px" width:"10px" height:"10px" style:"pill|passive" sk.bg:$item.tagColor
-<Col-CardMeta "cardMeta"> gap:"3px"
--<Text-TimeLabel "timeLabel"> value:$timeLabel style:"caption" font-size:"11px"
--<Text-LocationLabel "locationLabel"> value:$item.location style:"muted" font-size:"11px" overflow:"hidden" text-overflow:"ellipsis" white-space:"nowrap"

# Frontend Event Handlers
<Col-CardShell "cardShell">.@click()
-@editRequested($item._id)

# Frontend Internal Methods
# Frontend Pipeline Funcs
</Component-ScheduleEventCard>
