// VL_VERSION:4.1
// Preview: width:100% height:620px
<Component-EventEditorForm "root"> containerType:col gap:"14px"

# Frontend Public Props
$form({title:STRING,dayOfWeek:INT,startSlot:INT,endSlot:INT,teacher:STRING,location:STRING,tagColor:STRING,notes:STRING}) = {title:"",dayOfWeek:1,startSlot:1,endSlot:1,teacher:"",location:"",tagColor:"#2563EB",notes:""}
$isCreateMode(BOOL) = true
$isSaving(BOOL) = false

# Frontend Public Events
EVENT @change(formData({title:STRING,dayOfWeek:INT,startSlot:INT,endSlot:INT,teacher:STRING,location:STRING,tagColor:STRING,notes:STRING}))
EVENT @submit(formData({title:STRING,dayOfWeek:INT,startSlot:INT,endSlot:INT,teacher:STRING,location:STRING,tagColor:STRING,notes:STRING}))
EVENT @cancel()
EVENT @delete()

# Frontend Global Vars
$draftTitle(STRING) = ""
$draftDayOfWeek(STRING) = "1"
$draftStartSlot(STRING) = "1"
$draftEndSlot(STRING) = "1"
$draftTeacher(STRING) = ""
$draftLocation(STRING) = ""
$draftTagColor(STRING) = "#2563EB"
$draftNotes(STRING) = ""

# Frontend Tree
<Col-FormFields "formFields"> gap:"14px"
-<Col-TitleField "titleField"> gap:"6px"
--<Text-TitleLabel "titleLabel"> value:"课程名称" style:"caption" font-size:"12px"
--<Input-TitleInput "titleInput"> value:$draftTitle placeholder:"Advanced Mathematics" style:"neutral|outlined|default|md" width:100%
-<Row-ScheduleNumbers "scheduleNumbers"> width:100% gap:"12px"
--<Col-DayField "dayField"> gap:"6px" flex:"1"
---<Text-DayLabel "dayLabel"> value:"星期 (1-5)" style:"caption" font-size:"12px"
---<Input-DayInput "dayInput"> value:$draftDayOfWeek type:"number" style:"neutral|outlined|default|md" width:100%
--<Col-StartField "startField"> gap:"6px" flex:"1"
---<Text-StartLabel "startLabel"> value:"开始节次" style:"caption" font-size:"12px"
---<Input-StartInput "startInput"> value:$draftStartSlot type:"number" style:"neutral|outlined|default|md" width:100%
--<Col-EndField "endField"> gap:"6px" flex:"1"
---<Text-EndLabel "endLabel"> value:"结束节次" style:"caption" font-size:"12px"
---<Input-EndInput "endInput"> value:$draftEndSlot type:"number" style:"neutral|outlined|default|md" width:100%
-<Col-TeacherField "teacherField"> gap:"6px"
--<Text-TeacherLabel "teacherLabel"> value:"教师" style:"caption" font-size:"12px"
--<Input-TeacherInput "teacherInput"> value:$draftTeacher placeholder:"Dr. Lin" style:"neutral|outlined|default|md" width:100%
-<Col-LocationField "locationField"> gap:"6px"
--<Text-LocationLabel "locationLabel"> value:"地点" style:"caption" font-size:"12px"
--<Input-LocationInput "locationInput"> value:$draftLocation placeholder:"Room A301" style:"neutral|outlined|default|md" width:100%
-<Col-ColorField "colorField"> gap:"6px"
--<Text-ColorLabel "colorLabel"> value:"标签颜色" style:"caption" font-size:"12px"
--<Input-ColorInput "colorInput"> value:$draftTagColor placeholder:"#2563EB" style:"neutral|outlined|default|md" width:100%
-<Col-NotesField "notesField"> gap:"6px"
--<Text-NotesLabel "notesLabel"> value:"备注" style:"caption" font-size:"12px"
--<Textarea-NotesInput "notesInput"> value:$draftNotes placeholder:"Add homework, reminder, or classroom notes." style:"neutral|outlined|default|md" width:100% min-height:"180px"

<Row-FormActions "formActions"> justify-content:"space-between" align-items:"center" gap:"12px" padding-top:"6px"
-<If-ShowDelete> conditions:(!$isCreateMode)
--<Button-DeleteEntry "deleteEntryButton"> value:"删除" style:"danger|ghost|default|sm|actionable" disabled:$isSaving
-<If-DeleteSpacer> conditions:$isCreateMode
--<Row-DeleteSpacer "deleteSpacer"> width:"1px" height:"1px"
-<Row-ActionGroup "actionGroup"> gap:"12px"
--<Button-CancelEntry "cancelEntryButton"> value:"取消" style:"neutral|outlined|default|sm|actionable" disabled:$isSaving
--<Button-SaveEntry "saveEntryButton"> value:($isSaving ? "Saving..." : ($isCreateMode ? "创建" : "保存")) style:"primary|filled|default|md|actionable" disabled:$isSaving

# Frontend Event Handlers
<Component-EventEditorForm "root">.@init()
-$draftTitle = $form.title
-$draftDayOfWeek = String($form.dayOfWeek)
-$draftStartSlot = String($form.startSlot)
-$draftEndSlot = String($form.endSlot)
-$draftTeacher = $form.teacher
-$draftLocation = $form.location
-$draftTagColor = $form.tagColor
-$draftNotes = $form.notes

<Input-TitleInput "titleInput">.@change(newValue, oldValue)
-$draftTitle = newValue
-emitChange() -> _changed

<Input-DayInput "dayInput">.@change(newValue, oldValue)
-$draftDayOfWeek = newValue
-emitChange() -> _changed

<Input-StartInput "startInput">.@change(newValue, oldValue)
-$draftStartSlot = newValue
-emitChange() -> _changed

<Input-EndInput "endInput">.@change(newValue, oldValue)
-$draftEndSlot = newValue
-emitChange() -> _changed

<Input-TeacherInput "teacherInput">.@change(newValue, oldValue)
-$draftTeacher = newValue
-emitChange() -> _changed

<Input-LocationInput "locationInput">.@change(newValue, oldValue)
-$draftLocation = newValue
-emitChange() -> _changed

<Input-ColorInput "colorInput">.@change(newValue, oldValue)
-$draftTagColor = newValue
-emitChange() -> _changed

<Textarea-NotesInput "notesInput">.@change(newValue, oldValue)
-$draftNotes = newValue
-emitChange() -> _changed

<Button-CancelEntry "cancelEntryButton">.@click()
-@cancel()

<Button-DeleteEntry "deleteEntryButton">.@click()
-@delete()

<Button-SaveEntry "saveEntryButton">.@click()
-@submit({title:$draftTitle,dayOfWeek:parseInt($draftDayOfWeek),startSlot:parseInt($draftStartSlot),endSlot:parseInt($draftEndSlot),teacher:$draftTeacher,location:$draftLocation,tagColor:$draftTagColor,notes:$draftNotes})

# Frontend Internal Methods
METHOD emitChange(); RETURN {success:BOOL}
-@change({title:$draftTitle,dayOfWeek:parseInt($draftDayOfWeek),startSlot:parseInt($draftStartSlot),endSlot:parseInt($draftEndSlot),teacher:$draftTeacher,location:$draftLocation,tagColor:$draftTagColor,notes:$draftNotes})
-RETURN {success:true}

# Frontend Pipeline Funcs
</Component-EventEditorForm>
