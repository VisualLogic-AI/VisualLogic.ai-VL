// VL_VERSION:4.1
// Preview: width:240px height:64px
<Component-ConflictBadge "root"> containerType:row align-items:"center" gap:"10px" padding:"10px 14px"

# Frontend Public Props
$count(INT) = 0
$message(STRING) = ""

# Frontend Derived Vars
$badgeText(STRING) = ($count > 0 ? (String($count) + " conflicts") : "0 conflicts")
$badgeBg(STRING) = ($count > 0 ? "#FEF2F2" : "#ECFDF5")
$badgeBorder(STRING) = ($count > 0 ? "1px solid #FCA5A5" : "1px solid #A7F3D0")
$dotColor(STRING) = ($count > 0 ? "#EF4444" : "#10B981")

# Frontend Tree
<Row-BadgeShell "badgeShell"> align-items:"center" gap:"10px" padding:"10px 14px" style:"solid|pill|passive" sk.bg:$badgeBg sk.borderColor:($count > 0 ? "#FCA5A5" : "#A7F3D0") sk.borderWidth:"1px"
-<Row-BadgeDot "badgeDot"> width:"10px" height:"10px" style:"pill|passive" sk.bg:$dotColor
-<Col-BadgeInfo "badgeInfo"> gap:"2px"
--<Text-BadgeText "badgeText"> value:$badgeText style:"contrast" font-size:"13px" font-weight:"700"
--<Text-BadgeMessage "badgeMessage"> value:$message style:"caption" font-size:"11px"

# Frontend Event Handlers

# Frontend Internal Methods
# Frontend Pipeline Funcs
</Component-ConflictBadge>
