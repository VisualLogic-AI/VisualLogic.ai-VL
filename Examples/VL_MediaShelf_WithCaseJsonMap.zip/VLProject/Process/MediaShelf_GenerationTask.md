# MediaShelf Generation Task

Generate a VL workspace rooted at `MediaShelf/`.

Rules:
- Keep all `.vx/.sc/.cp/.vs/.vdb/.vth` files on `// VL_VERSION:4.1`.
- Do not generate `Stage` in `Apps/MediaShelfApp.vx`.
- `Page` nodes must be direct children of the App root.
- App only orchestrates Sections and routes.
- Sections own business logic and ServiceDomain calls.
- Components stay presentation-only and must not call ServiceDomain.
- Favor mock-first implementation that works from the built-in database sample data.

Execution order:
1. Theme
2. ExtComponents
3. ServiceDomain and Database
4. Sections
5. App

Self-check:
- No Section nested inside another Section.
- No Component calling a ServiceDomain.
- No basic UI components directly under the App file.
- File root names match file names exactly.
