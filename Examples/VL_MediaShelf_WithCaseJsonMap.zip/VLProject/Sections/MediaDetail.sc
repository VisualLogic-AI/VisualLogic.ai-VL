// VL_VERSION:4.1
// Preview: width:100% min-height:720px
<Section-MediaDetail "root"> containerType:col padding:"24px" gap:"20px" style:"subtle|passive"

# Frontend Public Props
$mediaId(INT) = 0
$mediaType(STRING) = ""
$favoriteItems([{mediaId:INT,mediaType:STRING}]) = []

# Frontend Public Events
EVENT @goBack()
EVENT @favoriteChanged(mediaId(INT), mediaType(STRING), nextFavorite(BOOL))

# Frontend Public Methods
METHOD LoadDetail(mediaId(INT), mediaType(STRING)); RETURN {success:BOOL}
-$isLoading = true
-$notFound = false
-<ServiceDomain-MediaCatalog "mediaCatalog">.GetMediaDetail(mediaId, mediaType) -> _result
-$isLoading = false
-IF !_result.success
--$notFound = true
--$mediaDetail = {mediaId:0,mediaType:"",title:"",subtitle:"",coverUri:"",rating:0,tags:[],summary:"",creator:"",publishYear:0,durationOrPages:""}
--RETURN {success:false}
-$mediaDetail = _result.data
-RETURN {success:true}

# Frontend Global Vars
$mediaDetail({mediaId:INT,mediaType:STRING,title:STRING,subtitle:STRING,coverUri:STRING,rating:FLOAT,tags([STRING]),summary:STRING,creator:STRING,publishYear:INT,durationOrPages:STRING}) = {mediaId:0,mediaType:"",title:"",subtitle:"",coverUri:"",rating:0,tags:[],summary:"",creator:"",publishYear:0,durationOrPages:""}
$isLoading(BOOL) = false
$notFound(BOOL) = false

# Frontend Derived Vars
$isFavorite(BOOL) = $favoriteItems.some( (item) => item.mediaId == $mediaDetail.mediaId && item.mediaType == $mediaDetail.mediaType )
$metaLabel(STRING) = ($mediaDetail.mediaType == "movie" ? "Director" : "Author")
$yearLabel(STRING) = ("Published: " + $mediaDetail.publishYear)

# Frontend Tree
<ServiceDomain-MediaCatalog "mediaCatalog">
-<Service-GetMediaDetail> params:(mediaId(INT),mediaType(STRING)) returns:(success(BOOL),data({}))

<Button-BackButton "backButton"> value:"Back to library" style:"neutral|ghost|default|md|actionable"

<If-Loading> conditions:$isLoading
-<Col-LoadingState "loadingState"> gap:"8px" padding:"24px 0"
--<Text-LoadingTitle "loadingTitle"> value:"Loading detail..." style:"body"
--<Text-LoadingHint "loadingHint"> value:"Preparing the selected media item." style:"muted"

<If-NotFound> conditions:($notFound && !$isLoading)
-<Component-EmptyState "notFoundState"> title:"Media not found" description:"The selected movie or book is unavailable in the current catalog." height:"180px"

<If-HasDetail> conditions:(!$isLoading && !$notFound)
-<Col-DetailCard "detailCard"> style:"elevated|soft|passive" sk.borderColor:"#E2E8F0" sk.borderWidth:"1px" sk.radius:"12px" sk.shadow:"0 4px 12px rgba(0,0,0,0.08)" padding:"20px" gap:"18px"
--<Image-CoverImage "coverImage"> sourceUri:$mediaDetail.coverUri width:"100%" height:"320px"
--<Row-DetailHeader "detailHeader"> width:"100%" gap:"16px" align-items:"flex-start"
---<Col-HeadingBlock "headingBlock"> flex:"1" gap:"8px"
----<Text-TypeLabel "typeLabel"> value:($mediaDetail.mediaType == "movie" ? "Movie" : "Book") style:"caption"
----<Text-DetailTitle "detailTitle"> value:$mediaDetail.title style:"contrast" font-size:"30px" font-weight:"700" line-height:"1.2"
----<Text-DetailSubtitle "detailSubtitle"> value:$mediaDetail.subtitle style:"muted" font-size:"16px"
----<Text-CreatorLabel "creatorLabel"> value:($metaLabel + ": " + $mediaDetail.creator) style:"body" font-size:"15px"
---<Button-FavoriteButton "favoriteButton"> value:($isFavorite ? "Favorited" : "Add to favorites") style:"primary|filled|default|md|selectable" sk.bg:($isFavorite ? "#2563EB" : null)
--<Row-RatingRow "ratingRow"> gap:"12px" align-items:"center"
---<Component-RatingStars "ratingStars"> rating:$mediaDetail.rating width:"150px"
---<Text-RatingValue "ratingValue"> value:($mediaDetail.rating.toFixed(1) + " / 5.0") style:"body"
--<Row-TagRow "tagRow"> gap:"8px"
---<For-DetailTags> sourceArray:$mediaDetail.tags loopVar:[_item0,_index0]
----<Component-TagChip "tagChip"> label:_item0 intent:(_index0 == 0 ? "info" : (_index0 == 1 ? "success" : "warning")) width:"fit-content"
--<Text-YearText "yearText"> value:$yearLabel style:"muted"
--<Text-LengthText "lengthText"> value:$mediaDetail.durationOrPages style:"muted"
--<Text-SummaryTitle "summaryTitle"> value:"Summary" style:"caption"
--<Text-SummaryText "summaryText"> value:$mediaDetail.summary style:"body" line-height:"1.7"

# Frontend Event Handlers
<Button-BackButton "backButton">.@click()
-@goBack()

<Button-FavoriteButton "favoriteButton">.@click()
-@favoriteChanged($mediaDetail.mediaId, $mediaDetail.mediaType, !$isFavorite)

# Frontend Internal Methods

# Frontend Pipeline Funcs
</Section-MediaDetail>
