// VL_VERSION:4.1
// Preview: width:100% min-height:720px
<Section-LibraryHome "root"> containerType:col padding:"24px" gap:"20px" style:"subtle|passive"

# Frontend Public Props
$favoriteItems([{mediaId:INT,mediaType:STRING}]) = []

# Frontend Public Events
EVENT @openDetail(mediaId(INT), mediaType(STRING))
EVENT @favoriteChanged(mediaId(INT), mediaType(STRING), nextFavorite(BOOL))

# Frontend Public Methods

# Frontend Global Vars
$activeType(STRING) = "movie"
$searchKeyword(STRING) = ""
$mediaList([{}]) = []
$isLoading(BOOL) = false

# Frontend Tree
<ServiceDomain-MediaCatalog "mediaCatalog">
-<Service-GetMediaList> params:(mediaType(STRING),keyword(STRING)) returns:(success(BOOL),data([{}]))

<Col-PageShell "pageShell"> gap:"20px"
-<Col-HeaderBlock "headerBlock"> gap:"8px"
--<Text-PageEyebrow "pageEyebrow"> value:"MediaShelf" style:"caption"
--<Text-PageTitle "pageTitle"> value:"Movies and books in one collection" style:"contrast" font-size:"30px" font-weight:"700" line-height:"1.2"
--<Text-PageDescription "pageDescription"> value:"Search, rate, tag, favorite, and review your media collection." style:"muted" font-size:"15px"

-<Row-SearchRow "searchRow"> width:"100%" gap:"12px" align-items:"center"
--<Input-SearchInput "searchInput"> flex:"1" style:"neutral|outlined|default|md" value:$searchKeyword placeholder:"Search by title, creator, or tag"
--<Button-SearchButton "searchButton"> value:"Search" style:"primary|filled|default|md|actionable"

-<Row-TabRow "tabRow"> gap:"12px"
--<Button-MovieTab "movieTab"> value:"Movies" style:"neutral|outlined|default|md|selectable" sk.bg:($activeType == "movie" ? "#DBEAFE" : null) sk.borderColor:($activeType == "movie" ? "#2563EB" : null) sk.fg:($activeType == "movie" ? "#2563EB" : null)
--<Button-BookTab "bookTab"> value:"Books" style:"neutral|outlined|default|md|selectable" sk.bg:($activeType == "book" ? "#DBEAFE" : null) sk.borderColor:($activeType == "book" ? "#2563EB" : null) sk.fg:($activeType == "book" ? "#2563EB" : null)

-<If-Loading> conditions:$isLoading
--<Col-LoadingState "loadingState"> gap:"8px" padding:"20px 0"
---<Text-LoadingTitle "loadingTitle"> value:"Loading collection..." style:"body"
---<Text-LoadingHint "loadingHint"> value:"Fetching media cards from the mock catalog." style:"muted"

-<If-HasItems> conditions:($mediaList.length > 0 && !$isLoading)
--<Col-CardList "cardList"> gap:"16px"
---<For-MediaList> sourceArray:$mediaList loopVar:[_item0,_index0]
----<Component-MediaCard "mediaCard"> media:_item0 isFavorite:($favoriteItems.some( (item) => item.mediaId == _item0.mediaId && item.mediaType == _item0.mediaType )) height:"248px"

-<If-Empty> conditions:($mediaList.length == 0 && !$isLoading)
--<Component-EmptyState "emptyState"> title:"No media found" description:"Try another keyword or switch the current tab." height:"160px"

# Frontend Event Handlers
<Section-LibraryHome "root">.@init()
-loadMediaList() -> _result

<Input-SearchInput "searchInput">.@input(newValue, delta)
-$searchKeyword = newValue
-loadMediaList() -> _result

<Button-SearchButton "searchButton">.@click()
-loadMediaList() -> _result

<Button-MovieTab "movieTab">.@click()
-$activeType = "movie"
-loadMediaList() -> _result

<Button-BookTab "bookTab">.@click()
-$activeType = "book"
-loadMediaList() -> _result

<Component-MediaCard "mediaCard">.@open(mediaId, mediaType)
-@openDetail(mediaId, mediaType)

<Component-MediaCard "mediaCard">.@toggleFavorite(mediaId, mediaType, nextFavorite)
-@favoriteChanged(mediaId, mediaType, nextFavorite)

# Frontend Internal Methods
METHOD loadMediaList(); RETURN {success:BOOL}
-$isLoading = true
-<ServiceDomain-MediaCatalog "mediaCatalog">.GetMediaList($activeType, $searchKeyword) -> _result
-$isLoading = false
-GUARD (!_result.success) "Failed to load media list"
-$mediaList = _result.data
-RETURN {success:true}

# Frontend Pipeline Funcs
</Section-LibraryHome>
