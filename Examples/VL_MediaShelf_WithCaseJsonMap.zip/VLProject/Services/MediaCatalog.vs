// VL_VERSION:4.1
<ServiceDomain-MediaCatalog>

# Backend Tree
<VirtualTable-MediaItem "mediaItemTable"> sourceTable:MediaItem
-<Field-mediaId> type:INT sourceField:_id
-<Field-mediaType> type:STRING
-<Field-title> type:STRING
-<Field-subtitle> type:STRING
-<Field-coverUri> type:STRING
-<Field-rating> type:FLOAT
-<Field-tagsText> type:STRING
-<Field-summary> type:STRING
-<Field-creator> type:STRING
-<Field-publishYear> type:INT
-<Field-durationOrPages> type:STRING

# Services
SERVICE GetMediaList(mediaType(STRING), keyword(STRING));RETURN {success:BOOL,data:[{}]}
-<VirtualTable-MediaItem "mediaItemTable">.select([["mediaType","eq",mediaType]],[["rating","desc"],["publishYear","desc"]],[0,50]) -> _result
-_normalizedKeyword(STRING) = keyword.trim().toLowerCase()
-_mappedData([{}]) = _result.dataArray.map( (item) => ({mediaId:item.mediaId,mediaType:item.mediaType,title:item.title,subtitle:item.subtitle,coverUri:item.coverUri,rating:item.rating,tags:item.tagsText.split("|"),summary:item.summary,creator:item.creator,publishYear:item.publishYear,durationOrPages:item.durationOrPages}) )
-IF _normalizedKeyword == ""
--RETURN {success:true,data:_mappedData}
-_filteredData([{}]) = _mappedData.filter( (item) => (item.title.toLowerCase().includes(_normalizedKeyword) || item.subtitle.toLowerCase().includes(_normalizedKeyword) || item.creator.toLowerCase().includes(_normalizedKeyword) || item.tags.join(" ").toLowerCase().includes(_normalizedKeyword)) )
-RETURN {success:true,data:_filteredData}

SERVICE GetMediaDetail(mediaId(INT), mediaType(STRING));RETURN {success:BOOL,data:{}}
-<VirtualTable-MediaItem "mediaItemTable">.select([["mediaId","eq",mediaId],["mediaType","eq",mediaType]],null,[0,1]) -> _result
-IF _result.dataArray.length == 0
--RETURN {success:false,data:{}}
-_item({}) = _result.dataArray[0]
-_detail({}) = {mediaId:_item.mediaId,mediaType:_item.mediaType,title:_item.title,subtitle:_item.subtitle,coverUri:_item.coverUri,rating:_item.rating,tags:_item.tagsText.split("|"),summary:_item.summary,creator:_item.creator,publishYear:_item.publishYear,durationOrPages:_item.durationOrPages}
-RETURN {success:true,data:_detail}

# Backend Event Handlers
# Transactions
# Backend Internal Methods
# Backend Pipeline Funcs
</ServiceDomain-MediaCatalog>
