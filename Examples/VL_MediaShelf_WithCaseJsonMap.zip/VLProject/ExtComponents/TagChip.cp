// VL_VERSION:4.1
// Preview: width:fit-content height:28px
<Component-TagChip "root"> containerType:row padding:"6px 12px" align-items:"center" style:"pill|passive" sk.bg:($intent == "success" ? "#ECFDF5" : ($intent == "warning" ? "#FEF3C7" : "#EFF6FF")) sk.radius:"9999px"

# Frontend Public Props
$label(STRING) = ""
$intent(STRING) = "info"

# Frontend Public Events

# Frontend Derived Vars
$foregroundColor(STRING) = ($intent == "success" ? "#10B981" : ($intent == "warning" ? "#F59E0B" : "#3B82F6"))

# Frontend Tree
<Text-TagLabel "tagLabel"> value:$label style:"caption" sk.fg:$foregroundColor font-size:"12px"

# Frontend Event Handlers

# Frontend Internal Methods

# Frontend Pipeline Funcs
</Component-TagChip>
