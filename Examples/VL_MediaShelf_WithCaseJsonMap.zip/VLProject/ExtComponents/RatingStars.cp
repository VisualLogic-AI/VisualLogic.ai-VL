// VL_VERSION:4.1
// Preview: width:150px height:24px
<Component-RatingStars "root"> containerType:row gap:"4px" align-items:"center"

# Frontend Public Props
$rating(FLOAT) = 0
$max(INT) = 5

# Frontend Public Events

# Frontend Derived Vars
$ratingText(STRING) = $rating.toFixed(1)

# Frontend Tree
<Icon-StarOne "starOne"> fontSet:"fa-solid-900" content:"f005" font-size:"14px" sk.fg:($rating >= 1 ? "#F59E0B" : "#CBD5E1")
<Icon-StarTwo "starTwo"> fontSet:"fa-solid-900" content:"f005" font-size:"14px" sk.fg:($rating >= 2 ? "#F59E0B" : "#CBD5E1")
<Icon-StarThree "starThree"> fontSet:"fa-solid-900" content:"f005" font-size:"14px" sk.fg:($rating >= 3 ? "#F59E0B" : "#CBD5E1")
<Icon-StarFour "starFour"> fontSet:"fa-solid-900" content:"f005" font-size:"14px" sk.fg:($rating >= 4 ? "#F59E0B" : "#CBD5E1")
<Icon-StarFive "starFive"> fontSet:"fa-solid-900" content:"f005" font-size:"14px" sk.fg:($rating >= 5 ? "#F59E0B" : "#CBD5E1")

# Frontend Event Handlers

# Frontend Internal Methods

# Frontend Pipeline Funcs
</Component-RatingStars>
