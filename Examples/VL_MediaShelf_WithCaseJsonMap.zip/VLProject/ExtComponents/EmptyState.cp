// VL_VERSION:4.1
// Preview: width:100% height:160px
<Component-EmptyState "root"> containerType:col align-items:"center" justify-content:"center" gap:"8px" style:"soft|passive" sk.bg:"#FFFFFF" sk.borderColor:"#E2E8F0" sk.borderWidth:"1px" sk.radius:"12px" padding:"20px"

# Frontend Public Props
$title(STRING) = ""
$description(STRING) = ""

# Frontend Public Events

# Frontend Derived Vars

# Frontend Tree
<Icon-EmptyIcon "emptyIcon"> fontSet:"fa-regular-400" content:"f02d" font-size:"28px" sk.fg:"#94A3B8"
<Text-EmptyTitle "emptyTitle"> value:$title style:"contrast" font-size:"20px" font-weight:"600"
<Text-EmptyDescription "emptyDescription"> value:$description style:"muted" text-align:"center" line-height:"1.6"

# Frontend Event Handlers

# Frontend Internal Methods

# Frontend Pipeline Funcs
</Component-EmptyState>
