// VL_VERSION:4.1
// Preview: width:100% height:248px
<Component-MediaCard "root"> containerType:col gap:"14px" style:"elevated|soft|passive" sk.borderColor:"#E2E8F0" sk.borderWidth:"1px" sk.radius:"12px" sk.shadow:"0 4px 12px rgba(0,0,0,0.08)" padding:"16px"

# Frontend Public Props
$media({mediaId:INT,mediaType:STRING,title:STRING,subtitle:STRING,coverUri:STRING,rating:FLOAT,tags([STRING]),summary:STRING,creator:STRING,publishYear:INT,durationOrPages:STRING}) = {mediaId:0,mediaType:"",title:"",subtitle:"",coverUri:"",rating:0,tags:[],summary:"",creator:"",publishYear:0,durationOrPages:""}
$isFavorite(BOOL) = false

# Frontend Public Events
EVENT @open(mediaId(INT), mediaType(STRING))
EVENT @toggleFavorite(mediaId(INT), mediaType(STRING), nextFavorite(BOOL))

# Frontend Derived Vars
$ratingText(STRING) = $media.rating.toFixed(1)

# Frontend Tree
<Row-CardBody "cardBody"> width:"100%" gap:"16px" align-items:"flex-start"
-<Image-CoverImage "coverImage"> sourceUri:$media.coverUri width:"140px" height:"180px"
-<Col-InfoBlock "infoBlock"> flex:"1" gap:"10px"
--<Row-TitleRow "titleRow"> width:"100%" gap:"12px" align-items:"flex-start"
---<Col-TitleBlock "titleBlock"> flex:"1" gap:"6px"
----<Text-TypeLabel "typeLabel"> value:($media.mediaType == "movie" ? "Movie" : "Book") style:"caption"
----<Text-TitleText "titleText"> value:$media.title style:"contrast" font-size:"22px" font-weight:"700" line-height:"1.25"
----<Text-SubtitleText "subtitleText"> value:$media.subtitle style:"muted" font-size:"15px"
---<Button-FavoriteButton "favoriteButton"> style:"neutral|ghost|pill|sm|selectable" sk.bg:($isFavorite ? "#DBEAFE" : null) sk.fg:($isFavorite ? "#2563EB" : null) ariaLabel:"Toggle favorite"
----<Icon-FavoriteIcon "favoriteIcon"> fontSet:"fa-solid-900" content:"f004" font-size:"16px"
--<Text-CreatorText "creatorText"> value:$media.creator style:"body"
--<Row-RatingRow "ratingRow"> gap:"8px" align-items:"center"
---<Component-RatingStars "ratingStars"> rating:$media.rating width:"150px"
---<Text-RatingText "ratingText"> value:($ratingText + " / 5.0") style:"muted"
--<Row-TagRow "tagRow"> gap:"8px"
---<For-CardTags> sourceArray:$media.tags loopVar:[_item0,_index0]
----<Component-TagChip "tagChip"> label:_item0 intent:(_index0 == 0 ? "info" : (_index0 == 1 ? "success" : "warning")) width:"fit-content"
--<Text-SummaryText "summaryText"> value:$media.summary style:"muted" font-size:"14px" line-height:"1.6"

# Frontend Event Handlers
<Row-CardBody "cardBody">.@click()
-@open($media.mediaId, $media.mediaType)

<Button-FavoriteButton "favoriteButton">.@click()
-@toggleFavorite($media.mediaId, $media.mediaType, !$isFavorite)

# Frontend Internal Methods

# Frontend Pipeline Funcs
</Component-MediaCard>
